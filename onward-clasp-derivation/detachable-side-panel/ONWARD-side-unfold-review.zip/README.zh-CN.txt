SoulGrain ONWARD 鞋侧拆离与原裁片平铺研究
web/ 是相对路径静态构建，需通过静态 HTTP 托管打开 detachable-side.html（手机无需开发环境，可使用在线预览）。
web/detachable-side-panel/ 含 GLB、Blender、同拓扑数据、毫米 SVG、截图、视频与验证报告。
source/ 保存相关源码与原纸样工程；完整仓库及历史位于 https://github.com/siriguleng15/soulgrain-onward/tree/feat/onward-detachable-side-panel 。生成所需既有数据以仓库为准。
平铺数字一致性不等于实物工艺认证。底部包覆边界、隐藏构形与材料伸缩仍需实物验证。未进行 iPad Safari 实机测试。
