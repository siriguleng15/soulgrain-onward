# Soulgrain ONWARD / NIGHTFALL — 可编辑展示源码包

这是源码与必要资产包，**不是解压后直接双击的离线网页**。直接查看请使用在线预览：

https://siriguleng15.github.io/soulgrain-onward/onward-immersive/immersive-showcase.html

## 本地运行与独立构建

需要 Node.js 22.12+（或 20.19+）与 npm。保留仓库原始 package.json 和锁文件；依赖可能包含本展示未使用的项目组件。不要使用原项目的 npm run build 命令，因为此包只包含独立展示所需的源文件。

```bash
npm ci
npx tsc --noEmit
npx vite --host 127.0.0.1 --open /immersive-showcase.html
```

生成相对路径的独立静态页面（Linux / macOS）：

```bash
node scripts/build-immersive-showcase.mjs /tmp/onward-immersive-build ./
python3 -m http.server 4521 --bind 127.0.0.1 --directory /tmp/onward-immersive-build
```

浏览器打开 http://127.0.0.1:4521/immersive-showcase.html 。在线网页已经提供实时三维体验，不要求访客安装开发环境。

## 包内范围与限制

- 包含独立页面、TypeScript 源码、Three.js 翻筒与织物法线复用模块、构建配置和必要彩色 GLB / 翻筒结构 JSON。
- 不包含 node_modules、Git 凭据、其他网站及工作台源码、原 Blender 工程、重复截图或录屏。完整测试、截图与过程视频由在线审核页提供。
- 模型是彩色 V8 广告派生资产，保留早期绳状扣袢；它不是后期真实裁片研究中的扁平 PU 扣件系统。源字节 SHA-256 见 package-manifest.json。
- 参考网站访问阻断、有限贴图细节、翻筒几何展开与 iPad Safari 尚未实机测试等边界见 research/immersive-showcase/README.zh-CN.md。
- 基础鞋模改编自 theunclerulez 的 Generic “Converse style” Sneakers（CC BY 4.0）；Soulgrain 已修改几何与材质。来源：https://sketchfab.com/3d-models/generic-converse-style-sneakers-f7858a5612504c4193ca4c61125d6244 ，许可证：https://creativecommons.org/licenses/by/4.0/ 。用户品牌图案和原有模型的权利不因打包而改变。

研究说明中的完整 QA 命令仅适用于完整 Git 仓库；本精简源码包未包含验证脚本和额外原始 V8 审计模型。包内支持前端运行、TypeScript 检查和独立构建，完整证据请查看在线审核页。
