from pathlib import Path
import json,hashlib,subprocess
import numpy as np
from scipy.io import wavfile
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];fs,x=wavfile.read(R/'analysis/original_decoded.wav');x=x.astype('f8');mono=x.mean(axis=1)
n=len(x);duration=n/fs;win=int(fs*.1);rms=np.sqrt(np.mean(mono[:n//win*win].reshape(-1,win)**2,axis=1));db=20*np.log10(np.maximum(rms,1e-12));times=np.arange(len(rms))*.1
f,psd=signal.welch(mono,fs,nperseg=16384,noverlap=8192);power=np.trapezoid(psd,f)
bands={}
for lo,hi in [(0,20),(20,50),(50,100),(100,500),(500,2000),(2000,5000),(5000,10000),(10000,16000),(16000,22050)]:
 m=(f>=lo)&(f<hi);v=np.trapezoid(psd[m],f[m]);bands[f'{lo}-{hi}Hz']={'power_fraction':float(v/power),'rms_dbfs':float(10*np.log10(max(v,1e-20)))}
active=db>-45;low=np.flatnonzero(db<-45);runs=[]
for ar in np.split(low,np.flatnonzero(np.diff(low)>1)+1):
 if len(ar)>=3:runs.append({'start':float(ar[0]*.1),'end':float((ar[-1]+1)*.1),'rms_dbfs_mean':float(db[ar].mean())})
hum={}
for hz in [50,60,100,120]:
 peak=np.max(psd[np.abs(f-hz)<2]);side=psd[(np.abs(f-hz)>5)&(np.abs(f-hz)<15)];hum[str(hz)]=float(10*np.log10(max(peak,1e-20)/max(np.median(side),1e-20)))
diff=np.diff(x,axis=0);sat=np.abs(x)>=.999
audit={'source_sha256':hashlib.sha256((R/'inputs/original.mp3').read_bytes()).hexdigest(),'sample_rate':int(fs),'channels':x.shape[1],'decoded_frames':n,'decoded_duration_seconds':duration,'peak_dbfs':float(20*np.log10(np.max(np.abs(x)))),'rms_dbfs':float(20*np.log10(np.sqrt(np.mean(x*x)))),'dc':np.mean(x,axis=0).tolist(),'left_right_correlation':float(np.corrcoef(x.T)[0,1]),'stereo_difference_rms_dbfs':float(20*np.log10(max(np.sqrt(np.mean((x[:,0]-x[:,1])**2)),1e-12))),'samples_abs_ge_0_999':int(sat.sum()),'max_sample_jump':float(np.max(np.abs(diff))),'rms_100ms_percentiles_dbfs':{str(q):float(np.percentile(db,q)) for q in [0,1,5,10,50,90,99,100]},'quiet_runs_below_minus45_dbfs':runs,'hum_peak_to_local_median_db':hum,'bands':bands,'noise_profile_caution':'Quiet musical frames are not automatically a noise-only reference. No missing-note reconstruction is authorized.'}
(R/'analysis/source_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));np.savez_compressed(R/'analysis/time_frequency_data.npz',rms_dbfs=db,rms_times=times,freq=f,psd=psd)
fig,ax=plt.subplots(3,1,figsize=(13,10),constrained_layout=True);stride=max(1,n//10000);t=np.arange(0,n,stride)/fs
ax[0].plot(t,x[::stride,0],lw=.4,label='L');ax[0].plot(t,x[::stride,1],lw=.4,alpha=.6,label='R');ax[0].set(xlabel='Time / s',ylabel='Amplitude',title='Original decoded MP3');ax[0].legend()
ax[1].plot(times,db,lw=.7);ax[1].set(xlabel='Time / s',ylabel='100 ms RMS / dBFS');ax[1].grid(alpha=.2)
ax[2].semilogx(f[1:],10*np.log10(psd[1:]+1e-20));ax[2].set(xlim=(20,22050),xlabel='Frequency / Hz',ylabel='PSD / dBFS/Hz');ax[2].grid(alpha=.2);fig.savefig(R/'analysis/source_overview.png',dpi=160);plt.close(fig)
ff,tt,zz=signal.stft(mono,fs,nperseg=2048,noverlap=1536);fig,ax=plt.subplots(figsize=(14,5));m=ax.pcolormesh(tt,ff,20*np.log10(np.abs(zz)+1e-9),vmin=-90,vmax=-25,shading='auto',rasterized=True);ax.set(ylim=(0,18000),xlabel='Time / s',ylabel='Frequency / Hz',title='Original spectrogram (not a reconstruction)');fig.colorbar(m,ax=ax,label='dBFS');fig.tight_layout();fig.savefig(R/'analysis/source_spectrogram.png',dpi=160);plt.close(fig)
print(json.dumps(audit,indent=2),flush=True)
