"""Optional authorized-GPU route. NOT run in this environment: SAM weights unavailable.
Uses real SAM estimates, then projects masks onto original phase; never substitutes generated notes.
"""
import argparse
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True);p.add_argument('--out',default='sam_outputs');p.add_argument('--model',default='facebook/sam-audio-small');p.add_argument('--device',default='cuda');args=p.parse_args()
    import torch,torchaudio,numpy as np,soundfile as sf,json,subprocess,tempfile,hashlib
    from scipy import signal,ndimage
    import pyloudnorm as pyln
    from sam_audio import SAMAudio,SAMAudioProcessor
    if args.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA GPU unavailable. Use an adequate GPU runtime; no EQ fallback is presented as SAM.')
    dest=Path(args.out);dest.mkdir(parents=True,exist_ok=True);src=Path(args.input)
    subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(src),'-c:a','pcm_f32le',str(dest/'decoded_input.wav')],check=True)
    x,sr=sf.read(dest/'decoded_input.wav',dtype='float32',always_2d=True)
    model=SAMAudio.from_pretrained(args.model).eval().to(args.device);processor=SAMAudioProcessor.from_pretrained(args.model);model_sr=processor.audio_sampling_rate
    prompts={'plucked_candidate':'plucked string instrument','bowed_candidate':'bowed string instrument'};segment=8*sr;overlap=2*sr;step=segment-overlap;starts=[0]
    while starts[-1]+segment<len(x):starts.append(starts[-1]+step)
    estimates={k:np.zeros(len(x),'f4') for k in prompts};weight=np.zeros(len(x),'f4')
    for j,start in enumerate(starts):
        end=min(len(x),start+segment);length=end-start;piece=x[start:end].mean(axis=1);piece=np.pad(piece,(0,segment-length));temporary=dest/'current_chunk.wav';sf.write(temporary,piece,sr,subtype='FLOAT')
        window=np.ones(length,'f4');fade=min(overlap,length)
        if start:window[:fade]=np.sin(np.linspace(0,np.pi/2,fade))**2
        if end<len(x):window[-fade:]*=np.cos(np.linspace(0,np.pi/2,fade))**2
        for key,prompt in prompts.items():
            batch=processor(audios=[str(temporary)],descriptions=[prompt]).to(args.device)
            with torch.inference_mode():result=model.separate(batch,predict_spans=False,reranking_candidates=1)
            y=result.target.detach().float().cpu();y=y.reshape(-1,y.shape[-1]).mean(0)
            if model_sr!=sr:y=torchaudio.functional.resample(y,model_sr,sr)
            y=y.numpy();y=np.pad(y,(0,max(0,segment-len(y))))[:length];estimates[key][start:end]+=y*window
        weight[start:end]+=window;print(f'SAM chunk {j+1}/{len(starts)} complete',flush=True)
    for key in estimates:estimates[key]/=np.maximum(weight,1e-8)
    fft=4096;hop=1024;mono=x.mean(1);_,_,z=signal.stft(mono,sr,nperseg=fft,noverlap=fft-hop);masks={}
    for key,y in estimates.items():
        _,_,zy=signal.stft(y,sr,nperseg=fft,noverlap=fft-hop);m=np.clip(np.abs(zy)/(np.abs(z)+1e-10),0,1);masks[key]=ndimage.gaussian_filter(m,(1.,1.))
    # Max union avoids counting common harmonics twice. The two candidates are not additive stems.
    masks['B_SAM_Union']=np.maximum(masks['plucked_candidate'],masks['bowed_candidate']);versions={'Original':x}
    for key,m in masks.items():
        channels=[]
        for ch in range(x.shape[1]):
            _,_,zx=signal.stft(x[:,ch],sr,nperseg=fft,noverlap=fft-hop);_,y=signal.istft(zx*m,sr,nperseg=fft,noverlap=fft-hop);channels.append(y[:len(x)])
        versions[key]=np.stack(channels,1).astype('f4')
    versions['B_SAM_Removed']=x-versions['B_SAM_Union'];meter=pyln.Meter(sr);measures={}
    for k,y in versions.items():
        # Conservative sample-peak headroom. Final true-peak verification is still recommended.
        measures[k]={'lufs':float(meter.integrated_loudness(y)),'sample_peak_dbfs':float(20*np.log10(np.max(np.abs(y))+1e-20))}
    target=min([-23.]+[v['lufs']-3-v['sample_peak_dbfs'] for v in measures.values()]);gains={}
    for k,y in versions.items():
        gain=target-measures[k]['lufs'];gains[k]=gain;wav=dest/(k+'_Matched.wav');sf.write(wav,y*10**(gain/20),sr,subtype='PCM_24');subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(wav),'-c:a','libmp3lame','-b:a','320k',str(wav.with_suffix('.mp3'))],check=True)
    (dest/'sam_run_report.json').write_text(json.dumps({'model':args.model,'prompts':prompts,'device':args.device,'model_sampling_rate':model_sr,'original_sampling_rate':sr,'source_frames':len(x),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'segment_seconds':8,'overlap_seconds':2,'predict_spans':False,'reranking_candidates':1,'mask_method':'max union projected onto original complex stereo spectrum','target_lufs':target,'gain_db':gains,'pre_gain_metrics':measures,'candidate_tracks_are_not_additive':True,'ethnic_instrument_identity_requires_audition':True},indent=2))
    print('Done. Inspect removed audio for lost musical content. Model identity is not a guarantee of instrument purity.')
if __name__=='__main__':main()
