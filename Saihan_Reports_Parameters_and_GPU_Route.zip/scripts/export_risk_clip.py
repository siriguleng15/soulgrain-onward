"""Additional same-time excerpt covering the strongest model residual, not only favorable passages."""
from pathlib import Path
import numpy as np,soundfile as sf,pyloudnorm as pyln,json,subprocess
from scipy import signal
R=Path(__file__).resolve().parents[1];sr=44100;meter=pyln.Meter(sr);start,end=140,180;root=R/'output';folder=root/'comparisons/140_180';folder.mkdir(parents=True,exist_ok=True)
paths={'Original':'original_decoded.wav','A_Conservative':'A_unmatched_float.wav','B_AI_Other_Approximation':'B_unmatched_float.wav','B_Removed_Check_For_Lost_Strings':'B_removed_unmatched_float.wav'}
clips={k:sf.read(R/'analysis'/p,start=start*sr,frames=(end-start)*sr,dtype='float32',always_2d=True)[0] for k,p in paths.items()}
fade=int(.005*sr);ramp=np.linspace(0,1,fade,dtype='f4')
def tp(y):return float(20*np.log10(np.max(np.abs(signal.resample_poly(y,4,1,axis=0)))+1e-20))
for y in clips.values():y[:fade]*=ramp[:,None];y[-fade:]*=ramp[::-1,None]
metrics={k:(float(meter.integrated_loudness(y)),tp(y)) for k,y in clips.items()};target=np.floor(min([-23.]+[i-2-t for i,t in metrics.values()])*10)/10
group={'start_seconds':start,'end_seconds':end,'duration_seconds':40,'common_target_lufs':float(target),'identical_edge_fade_ms':5,'selection_reason':'Covers the strongest residual near 144 s and another near 151.5 s. Not a claim these sounds are noise.','versions':{}}
for k,y in clips.items():
 gain=target-metrics[k][0]
 for _ in range(5):
  w=(y*10**(gain/20)).astype('f4');delta=target-float(meter.integrated_loudness(w))
  if abs(delta)<.003:break
  gain+=delta
 wav=folder/(k+'.wav');mp3=wav.with_suffix('.mp3');sf.write(wav,w,sr,subtype='PCM_24');subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(wav),'-c:a','libmp3lame','-b:a','320k','-write_xing','1',str(mp3)],check=True)
 dec,_=sf.read(mp3,dtype='float32',always_2d=True);assert len(dec)==len(w)
 def m(v):return {'lufs':float(meter.integrated_loudness(v)),'true_peak_dbfs_4x':tp(v),'sample_peak_dbfs':float(20*np.log10(np.max(np.abs(v))+1e-20))}
 group['versions'][k]={'wav':str(wav.relative_to(root)),'mp3':str(mp3.relative_to(root)),'gain_db':float(gain),'gain_linear':float(10**(gain/20)),'frames':len(w),'wav_metrics':m(w),'mp3_decoded_metrics':m(dec),'mp3_roundtrip_frames_equal':True}
for fmt in ['wav_metrics','mp3_decoded_metrics']:
 levels=[v[fmt]['lufs'] for v in group['versions'].values()];assert max(levels)-min(levels)<.05
 assert max(v[fmt]['true_peak_dbfs_4x'] for v in group['versions'].values())<-.5
p=R/'analysis/final_loudness_and_exports.json';report=json.loads(p.read_text());report['comparisons']['140_180']=group;p.write_text(json.dumps(report,ensure_ascii=False,indent=2));print('RISK_EXCERPT_COMPLETE',target,flush=True)
