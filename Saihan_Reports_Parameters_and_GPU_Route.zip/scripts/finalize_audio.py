from pathlib import Path
import json,subprocess,hashlib,time
import numpy as np,soundfile as sf,pyloudnorm as pyln
from scipy import signal,ndimage
R=Path(__file__).resolve().parents[1];OUT=R/'output';OUT.mkdir(exist_ok=True);(OUT/'full').mkdir(exist_ok=True);(OUT/'comparisons').mkdir(exist_ok=True)
sr=44100;x,_=sf.read(R/'analysis/original_decoded.wav',dtype='float32',always_2d=True);A,_=sf.read(R/'analysis/A_unmatched_float.wav',dtype='float32',always_2d=True);n=len(x)
stems={k:sf.read(R/'analysis/raw_ai_stems'/f'{k}.wav',dtype='float32',always_2d=True)[0] for k in ['drums','bass','other','vocals']}
nfft=4096;hop=1024;energies={}
for key,v in stems.items():
 energy=None
 for ch in range(2):
  f,t,z=signal.stft(v[:,ch],sr,nperseg=nfft,noverlap=nfft-hop,boundary='zeros',padded=True);p=np.abs(z)**2;energy=p if energy is None else energy+p
 energies[key]=energy
denom=sum(energies.values());mask=energies['other']/(denom+1e-18);mask=ndimage.gaussian_filter(mask,sigma=(1.,1.));mask=np.clip(mask,0.,1.)
# Apply only attenuation to the original complex stereo spectrum. Neural waveforms
# serve as mask evidence; none are directly substituted as new musical notes.
base=signal.sosfiltfilt(signal.butter(2,12,btype='highpass',fs=sr,output='sos'),x,axis=0).astype('f4');parts=[]
for ch in range(2):
 f,t,z=signal.stft(base[:,ch],sr,nperseg=nfft,noverlap=nfft-hop,boundary='zeros',padded=True)
 _,v=signal.istft(z*mask,sr,nperseg=nfft,noverlap=nfft-hop,boundary=True);parts.append(v[:n])
B=np.stack(parts,axis=1).astype('f4');residual=(x-B).astype('f4');sf.write(R/'analysis/B_unmatched_float.wav',B,sr,subtype='FLOAT');sf.write(R/'analysis/B_removed_unmatched_float.wav',residual,sr,subtype='FLOAT')
mask_info={'ai_source_class':'other','contains_proven_instruments':False,'model_predictions_used':['drums','bass','other','vocals'],'method':'AI-estimated generalized Wiener power mask: P_other / sum(P_all), smoothed and applied to original stereo complex STFT','fft':nfft,'hop':hop,'linked_stereo':True,'mask_min':float(mask.min()),'mask_max':float(mask.max()),'mask_mean':float(mask.mean()),'mask_smoothing_sigma':[1.,1.],'neural_waveforms_directly_substituted':False,'pitch_or_tempo_change':False,'residual_definition':'original decoded float waveform minus B before normalization','residual_max_reconstruction_error':float(np.max(np.abs(B.astype('f8')+residual.astype('f8')-x.astype('f8')))),'no_ground_truth_sdr_available':True}
(R/'analysis/B_parameters.json').write_text(json.dumps(mask_info,ensure_ascii=False,indent=2));print('B_MASK_READY',mask_info,flush=True)
del stems,energies,denom,mask,base
meter=pyln.Meter(sr)
def truepeak(v):
 # Independent 4x oversampling, with padding at block boundaries.
 peak=0.;block=sr*10
 for st in range(0,len(v),block):
  a=max(0,st-64);b=min(len(v),st+block+64);up=signal.resample_poly(v[a:b],4,1,axis=0);lo=(st-a)*4;hi=(min(len(v),st+block)-a)*4;peak=max(peak,float(np.max(np.abs(up[lo:hi]))))
 return 20*np.log10(max(peak,1e-15))
def metrics(v):return {'lufs':float(meter.integrated_loudness(v)),'sample_peak_dbfs':float(20*np.log10(np.max(np.abs(v))+1e-20)),'true_peak_dbfs_4x':float(truepeak(v)),'rms_dbfs':float(20*np.log10(np.sqrt(np.mean(v.astype('f8')**2))+1e-20))}
def encode(name,v,folder,gain_db,target_lufs):
 # BS.1770 absolute gating can change the included blocks when a quiet residual is lifted.
 # Iterate constant gain only; no compressor/limiter or tempo change.
 for _ in range(5):
  w=(v*10**(gain_db/20)).astype('f4');error=target_lufs-float(meter.integrated_loudness(w))
  if abs(error)<.003:break
  gain_db+=error
 dest=folder/(name+'.wav');assert np.isfinite(w).all() and np.max(np.abs(w))<1
 sf.write(dest,w,sr,subtype='PCM_24');mp3=dest.with_suffix('.mp3')
 subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(dest),'-map_metadata','-1','-c:a','libmp3lame','-b:a','320k','-write_xing','1',str(mp3)],check=True)
 decoded,dfs=sf.read(mp3,dtype='float32',always_2d=True);assert dfs==sr and len(decoded)==len(w),(name,len(decoded),len(w))
 wm=metrics(w);mm=metrics(decoded)
 return {'wav':str(dest.relative_to(OUT)),'mp3':str(mp3.relative_to(OUT)),'gain_db':float(gain_db),'gain_linear':float(10**(gain_db/20)),'frames':len(w),'wav_metrics':wm,'mp3_decoded_metrics':mm,'mp3_roundtrip_frames_equal':True}
raw={'Original':x,'A_Conservative':A,'B_AI_Other_Approximation':B,'B_Removed_Check_For_Lost_Strings':residual};rawmetrics={k:metrics(v) for k,v in raw.items()}
# Include residual in matching, choose a common peak-safe target, and use only constant gains.
# A spiky residual must not be clipped or limited to make it artificially as loud as the mix.
target=min([-23.]+[m['lufs']-2.0-m['true_peak_dbfs_4x'] for m in rawmetrics.values()]);target=np.floor(target*10)/10
report={'reference':'ITU-R BS.1770 / pyloudnorm integrated loudness, constant gain only','full_common_target_lufs':float(target),'raw_metrics':rawmetrics,'full':{},'comparisons':{},'normalizer_dynamics_processing':False}
for k,v in raw.items():
 print('EXPORT_FULL',k,'target',target,flush=True);report['full'][k]=encode(k+'_Matched',v,OUT/'full',target-rawmetrics[k]['lufs'],target)
for start,stop in [(70,110),(175,215)]:
 key=f'{start:03d}_{stop:03d}';folder=OUT/'comparisons'/key;folder.mkdir(exist_ok=True);clips={k:v[start*sr:stop*sr].copy() for k,v in raw.items()}
 # Identical 5 ms fades at excerpt boundaries only; full-length outputs have no added fades.
 fade=int(.005*sr);ramp=np.linspace(0,1,fade,dtype='f4')
 for v in clips.values():v[:fade]*=ramp[:,None];v[-fade:]*=ramp[::-1,None]
 cm={k:metrics(v) for k,v in clips.items()};ct=min([-23.]+[m['lufs']-2-m['true_peak_dbfs_4x'] for m in cm.values()]);ct=np.floor(ct*10)/10
 group={'start_seconds':start,'end_seconds':stop,'duration_seconds':stop-start,'common_target_lufs':float(ct),'identical_edge_fade_ms':5,'versions':{}}
 for k,v in clips.items():
  print('EXPORT_CLIP',key,k,'target',ct,flush=True);group['versions'][k]=encode(k,v,folder,ct-cm[k]['lufs'],ct)
 report['comparisons'][key]=group
for name,data in [('full',report['full'])]+[(k,v['versions']) for k,v in report['comparisons'].items()]:
 wav_i=[v['wav_metrics']['lufs'] for v in data.values()];mp3_i=[v['mp3_decoded_metrics']['lufs'] for v in data.values()]
 assert max(wav_i)-min(wav_i)<.03,(name,wav_i)
 assert max(mp3_i)-min(mp3_i)<.15,(name,mp3_i)
 assert max(v['mp3_decoded_metrics']['true_peak_dbfs_4x'] for v in data.values())<-.5,(name,'MP3 peak risk')
print('LOUDNESS_MATCH_VALIDATED',flush=True)
report['source_frames_preserved']=all(v['frames']==n for v in report['full'].values());report['source_sha256_unchanged']=hashlib.sha256((R/'inputs/original.mp3').read_bytes()).hexdigest()=='f5619fa8d6a8bdc5caf7119c088d50039820f620067d20ecd2179f03cc197d3a';assert report['source_sha256_unchanged']
(R/'analysis/final_loudness_and_exports.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('AUDIO_EXPORT_COMPLETE',flush=True)
