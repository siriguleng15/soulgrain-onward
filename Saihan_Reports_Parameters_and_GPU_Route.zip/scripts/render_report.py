from pathlib import Path
import html,re,base64
R=Path(__file__).resolve().parents[1];O=R/'output'
def inline(s):
 s=html.escape(s);s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s);return re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s)
def render(md):
 out=[];lines=md.splitlines();i=0
 while i<len(lines):
  s=lines[i].strip()
  if not s:i+=1;continue
  if s.startswith('#'):
   n=len(s)-len(s.lstrip('#'));out.append(f'<h{n}>{inline(s[n:].strip())}</h{n}>');i+=1;continue
  if s.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].strip().startswith('|'):
    cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
    if not all(re.fullmatch(r'[:\- ]+',c or ' ') for c in cells):rows.append(cells)
    i+=1
   out.append('<table>')
   for j,row in enumerate(rows):
    tag='th' if j==0 else 'td';out.append('<tr>'+''.join(f'<{tag}>{inline(c)}</{tag}>' for c in row)+'</tr>')
   out.append('</table>');continue
  kind='ol' if re.match(r'^\d+\. ',s) else 'ul' if s.startswith('- ') else None
  if kind:
   out.append('<'+kind+'>')
   while i<len(lines):
    m=re.match(r'^\d+\. (.*)',lines[i].strip()) if kind=='ol' else re.match(r'^- (.*)',lines[i].strip())
    if not m:break
    out.append('<li>'+inline(m[1])+'</li>');i+=1
   out.append('</'+kind+'>');continue
  out.append('<p>'+inline(s)+'</p>');i+=1
 return '\n'.join(out)
css='''body{font-family:"Noto Sans CJK SC","Noto Sans",sans-serif;color:#172c31;font-size:10pt;line-height:1.7}h1{font-size:23pt;color:#174c56}h2{font-size:14pt;margin-top:24px;border-bottom:1px solid #abc;break-after:avoid}table{width:100%;border-collapse:collapse;font-size:8.4pt;margin:14px 0}td,th{border:1px solid #b9c5c9;padding:5px;vertical-align:top;overflow-wrap:anywhere}th{background:#e8f1f2}tr{break-inside:avoid}code{font-family:monospace;font-size:.85em;overflow-wrap:anywhere}p{orphans:3;widows:3;overflow-wrap:anywhere}li{margin-bottom:4px}.figure{break-before:page}img{width:100%;max-height:235mm;object-fit:contain}'''
body=render((O/'处理报告_简体中文.md').read_text())
for name,title,note in [('source_overview.png','附图 1：原音波形、动态与平均频谱','原始数据；未填补高频或缺失音符。'),('source_spectrogram.png','附图 2：原音频谱','约 9 kHz 后能量很弱，局部带宽也有变化。无法据此把所有缺损归因于最后一次 MP3 编码。'),('comparison_spectrogram_070_110.png','附图 3：同响度片段对照','Removed 单独匹配到相同响度，不能用图中其亮度解释原始能量占比。请试听它是否包含误删乐器。')]:
 b64=base64.b64encode((R/'analysis'/name).read_bytes()).decode();body+='<div class="figure"><h2>'+title+'</h2><p>'+note+'</p><img src="data:image/png;base64,'+b64+'"></div>'
(O/'Saihan_Audio_Report.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>赛罕：音频修复与 AI 分离报告</title><style>'+css+'</style><body>'+body+'</body></html>')
