"""Conservative linked-stereo restoration. Does not reconstruct missing notes/frequencies."""
from pathlib import Path
import numpy as np,soundfile as sf,json
from scipy import signal,ndimage
R=Path(__file__).resolve().parents[1];x,sr=sf.read(R/'analysis/original_decoded.wav',dtype='float32',always_2d=True);n=len(x)
# Remove measured DC and subsonic energy only. Zero-phase, no timing/pitch changes.
sos=signal.butter(2,12,btype='highpass',fs=sr,output='sos');clean=signal.sosfiltfilt(sos,x,axis=0).astype('f4')
nfft=4096;hop=1024;zs=[]
for ch in range(2):f,t,z=signal.stft(clean[:,ch],sr,nperseg=nfft,noverlap=nfft-hop,boundary='zeros',padded=True);zs.append(z)
Z=np.stack(zs);power=np.mean(np.abs(Z)**2,axis=0)
# No verified noise-only recording is available. A low-percentile floor is only a
# conservative upper-bound proxy, and strong harmonic peaks/transients are protected.
valid=(t>=1)&(t<239);floor=np.percentile(power[:,valid],5,axis=1);floor=ndimage.gaussian_filter1d(floor,1.5)
ratio=floor[:,None]/(power+1e-18);raw_gain=np.sqrt(np.maximum(1-.45*ratio,0))
min_gain=10**(-1.5/20);gain=np.clip(raw_gain,min_gain,1.)
local=ndimage.median_filter(power,size=(17,1));contrast=power/(local+1e-18);harmonic=np.clip((10*np.log10(contrast+1e-15)-3)/7,0,1)
harmonic=ndimage.maximum_filter(harmonic,size=(3,1));gain=1-(1-gain)*(1-.95*harmonic)
envelope=np.sqrt(np.mean(power,axis=0));baseline=ndimage.median_filter(envelope,size=9);transient=np.clip((envelope/(baseline+1e-15)-1.05)/.45,0,1);transient=ndimage.maximum_filter1d(transient,size=3)
gain=1-(1-gain)*(1-.95*transient[None,:]);gain=ndimage.gaussian_filter(gain,sigma=(1.2,1.0));gain=np.clip(gain,min_gain,1.)
y=[]
for z in Z:
 _,v=signal.istft(z*gain,sr,nperseg=nfft,noverlap=nfft-hop,boundary=True);y.append(v[:n])
y=np.stack(y,axis=1).astype('f4');sf.write(R/'analysis/A_unmatched_float.wav',y,sr,subtype='FLOAT');delta=x-y
report={'highpass_hz':12,'highpass_order':2,'highpass_zero_phase':True,'stft_fft':nfft,'hop':hop,'gain_stereo_linked':True,'noise_proxy':'5th-percentile time-frequency power over 1–239 s, not a verified noise-only profile','maximum_spectral_reduction_db':1.5,'spectral_subtraction_strength':.45,'harmonic_protection':'Local narrowband peaks, max 95% attenuation exemption','transient_protection':'Short-term envelope onset protection, max 95% attenuation exemption','gain_smoothing_freq_bins':1.2,'gain_smoothing_time_frames':1.0,'mean_spectral_attenuation_db':float(np.mean(-20*np.log10(gain))),'changed_signal_rms_relative_db':float(20*np.log10(np.sqrt(np.mean(delta.astype('f8')**2))/np.sqrt(np.mean(x.astype('f8')**2)))),'dc_before':x.mean(0).astype(float).tolist(),'dc_after':y.mean(0).astype(float).tolist(),'frames':n,'sample_rate':sr,'declick_applied':False,'hum_notches_applied':False,'inpainting_or_harmonic_synthesis':False,'missing_high_frequency_reconstruction':False,'time_stretch_pitch_shift':False}
(R/'analysis/A_parameters.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,indent=2),flush=True)
