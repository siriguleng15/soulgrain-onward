"""Actual pretrained Hybrid Demucs inference; no substitute/synthetic notes."""
from pathlib import Path
import numpy as np,soundfile as sf,torch,torchaudio,time,json,hashlib
R=Path(__file__).resolve().parents[1];torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(20261110);np.random.seed(20261110)
torch.hub.set_dir(str(R/'models/torch_hub'));bundle=torchaudio.pipelines.HDEMUCS_HIGH_MUSDB_PLUS
weights=R/'models/torch_hub/torchaudio/models/hdemucs_high_trained.pt'
if not weights.exists():bundle.get_model()
model=bundle._model_factory_func();model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True));model.eval()
x,sr=sf.read(R/'analysis/original_decoded.wav',dtype='float32',always_2d=True);assert sr==44100 and x.shape[1]==2
n=len(x);segment=8*sr;overlap=2*sr;step=segment-overlap;starts=[0]
while starts[-1]+segment<n:starts.append(starts[-1]+step)
out=np.zeros((4,2,n),'f4');normalizer=np.zeros(n,'f4');began=time.perf_counter()
# The model normalizes internally; no per-stem rescaling or random shifts.
for j,start in enumerate(starts):
 end=min(n,start+segment);part=x[start:end].T.copy();length=end-start
 if length<segment:part=np.pad(part,((0,0),(0,segment-length)))
 t=time.perf_counter()
 with torch.inference_mode():pred=model(torch.from_numpy(part)[None])[0].cpu().numpy()[:,:,:length]
 window=np.ones(length,'f4');fade=min(overlap,length)
 if start>0:window[:fade]=np.sin(np.linspace(0,np.pi/2,fade,dtype='f4'))**2
 if end<n:window[-fade:]*=np.cos(np.linspace(0,np.pi/2,fade,dtype='f4'))**2
 out[:,:,start:end]+=pred*window;normalizer[start:end]+=window
 print(f'CHUNK {j+1}/{len(starts)} original {start/sr:.1f}–{end/sr:.1f}s inference {time.perf_counter()-t:.2f}s total {time.perf_counter()-began:.1f}s',flush=True)
out/=np.maximum(normalizer,1e-8)[None,None,:]
raw=R/'analysis/raw_ai_stems';raw.mkdir(exist_ok=True)
metrics={}
for name,stem in zip(model.sources,out):
 sf.write(raw/(name+'.wav'),stem.T,sr,subtype='FLOAT');metrics[name]={'rms_dbfs':float(20*np.log10(np.sqrt(np.mean(stem.astype('f8')**2))+1e-20)),'peak_dbfs':float(20*np.log10(np.max(np.abs(stem))+1e-20))}
model_error=x-out.sum(0).T
report={'model':'torchaudio.pipelines.HDEMUCS_HIGH_MUSDB_PLUS','architecture':'Hybrid Demucs (HDemucs), not HTDemucs six-source','model_sources':model.sources,'parameters':sum(p.numel() for p in model.parameters()),'checkpoint_url':'https://download.pytorch.org/torchaudio/models/hdemucs_high_trained.pt','checkpoint_sha256':hashlib.sha256(weights.read_bytes()).hexdigest(),'checkpoint_bytes':weights.stat().st_size,'torch':torch.__version__,'torchaudio':torchaudio.__version__,'device':'cpu','threads':4,'segment_seconds':8,'overlap_seconds':2,'overlap_fraction':.25,'blend':'sin^2/cos^2 normalized overlap-add','sample_rate':sr,'frames':n,'random_shifts':0,'per_stem_rescaling':False,'text_prompt_support':False,'actual_text_prompt_run':False,'duration_processing_seconds':time.perf_counter()-began,'raw_stem_metrics':metrics,'raw_model_sum_error_rms_dbfs':float(20*np.log10(np.sqrt(np.mean(model_error.astype('f8')**2))+1e-20)),'instrument_identity_warning':'other is a generic learned music class, not a proven isolated sanxian or huur stem.'}
(R/'analysis/ai_inference.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('AI_INFERENCE_COMPLETE',report['duration_processing_seconds'],flush=True)
