import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {readFile} from 'node:fs/promises';
const root='/workspace/artifacts/saihan-audio-restore-20261110/output';
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const page=await browser.newPage();await page.setContent(await readFile(root+'/Saihan_Audio_Report.html','utf8'));await page.evaluate(()=>document.fonts.ready);
await page.pdf({path:root+'/Saihan_Audio_Report.pdf',format:'A4',printBackground:true,margin:{top:'16mm',bottom:'18mm',left:'15mm',right:'15mm'},displayHeaderFooter:true,headerTemplate:'<span></span>',footerTemplate:'<div style="width:100%;text-align:center;font-size:9px;color:#456">Saihan Audio Restoration · 2026-11-10 · <span class="pageNumber"></span>/<span class="totalPages"></span></div>'});await browser.close();
