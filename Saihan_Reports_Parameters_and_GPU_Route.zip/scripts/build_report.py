from pathlib import Path
import json,hashlib,zipfile,shutil,html,re,csv
import numpy as np,soundfile as sf
R=Path(__file__).resolve().parents[1];O=R/'output';audit=json.loads((R/'analysis/source_audit.json').read_text());a=json.loads((R/'analysis/A_parameters.json').read_text());b=json.loads((R/'analysis/B_parameters.json').read_text());ai=json.loads((R/'analysis/ai_inference.json').read_text());levels=json.loads((R/'analysis/final_loudness_and_exports.json').read_text());quality=json.loads((R/'analysis/quality_validation.json').read_text())
checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)});assert ok,name
check('Original source hash preserved',levels['source_sha256_unchanged'] and quality['source_sha256_unchanged']);check('Real pretrained model checkpoint used',len(ai['checkpoint_sha256'])==64 and ai['parameters']==83639368 and ai['frames']==audit['decoded_frames']);check('No false text-prompt claim',ai['text_prompt_support'] is False and ai['actual_text_prompt_run'] is False)
check('A and B preserve length/stereo/sample rate',quality['all_shapes_identical'] and levels['source_frames_preserved']);check('B plus removed waveform reconstructs input before gains',quality['residual_recombination_max_abs_error']<1e-6);check('A DC corrected without inpainting',max(abs(v) for v in a['dc_after'])<1e-5 and a['inpainting_or_harmonic_synthesis'] is False)
check('B applies only bounded original-phase attenuation',0<=b['mask_min']<=b['mask_max']<=1 and b['neural_waveforms_directly_substituted'] is False)
groups={'full':levels['full'],**{k:v['versions'] for k,v in levels['comparisons'].items()}}
manifest=[]
for group,versions in groups.items():
 wavs=[v['wav_metrics']['lufs'] for v in versions.values()];mp3s=[v['mp3_decoded_metrics']['lufs'] for v in versions.values()]
 check(group+' WAV loudness spread < 0.03 LU',max(wavs)-min(wavs)<.03);check(group+' MP3 loudness spread < 0.15 LU',max(mp3s)-min(mp3s)<.15)
 for name,v in versions.items():
  w=O/v['wav'];m=O/v['mp3'];wi=sf.info(w);mi=sf.info(m)
  check(group+' '+name+' real formats/frame alignment',wi.samplerate==mi.samplerate==44100 and wi.channels==mi.channels==2 and wi.frames==mi.frames==v['frames'] and wi.subtype=='PCM_24')
  check(group+' '+name+' no decoded MP3 clipping',v['mp3_decoded_metrics']['true_peak_dbfs_4x']<-.5)
  for p in [w,m]:manifest.append({'file':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
summary={'date':'2026-11-10','checks_passed':len(checks),'checks':checks,'audio_files':len(manifest),'A':'Conservative DC/subsonic removal and bounded 1.5 dB spectral attenuation','B':'Actually run HDemucs other-class estimate projected as a soft original-phase stereo mask, not verified isolated sanxian or huur','model_actually_run':ai['model'],'full_target_lufs':levels['full_common_target_lufs'],'comparison_targets_lufs':{k:v['common_target_lufs'] for k,v in levels['comparisons'].items()},'SAM_Audio_ran':False,'Roformer_ran':False,'subjective_ethnic_instrument_identity_confirmed':False,'residual_reconstruction_max_error':quality['residual_recombination_max_abs_error'],'source_sha256':audit['source_sha256']}
(O/'验证结果.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(O/'SHA256_audio_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));(O/'音量匹配参数.json').write_text(json.dumps(levels,ensure_ascii=False,indent=2))
with (O/'音量匹配参数.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.writer(f);writer.writerow(['group','version','gain_db','WAV_LUFS','MP3_decoded_LUFS','MP3_true_peak_dBFS','WAV_path','MP3_path'])
 for g,vs in groups.items():
  for n,v in vs.items():writer.writerow([g,n,v['gain_db'],v['wav_metrics']['lufs'],v['mp3_decoded_metrics']['lufs'],v['mp3_decoded_metrics']['true_peak_dbfs_4x'],v['wav'],v['mp3']])
report=f'''# 赛罕：保守修复与 AI 分离试验报告

2026-11-10 · 原文件：自作伴奏赛罕（何凤兰）.mp3

**推荐先试听 A 版。B 是真实模型运行后的“通用器乐近似提取试验”，没有完成经确认的三弦/胡尔独立纯轨。不要把 B 当作已经准确识别两件民族乐器的成品。**

## 1. 交付与试听方法

- `A_Conservative_Matched`：保留整场演奏的保守修复版。
- `B_AI_Other_Approximation_Matched`：AI 通用 other 类估计的原相位投射版本。
- `B_Removed_Check_For_Lost_Strings_Matched`：B 削弱或移除的声音，专门检查误删；**不是已确认的纯噪声轨**。
- `Original_Matched`：原录音解码后只调到相同响度，用于公平比较。
- 每个全曲版本及每个片段都有 **44.1 kHz 双声道 24-bit WAV** 和 **320 kbps MP3**。

优先打开 `Saihan_Listen_First_MP3.zip`。每个文件夹含同一原始时间段的 Original / A / B / Removed 四个版本，单个片段均为 **40 秒**：

| 文件夹 | 原录音位置 | 用途 |
| --- | --- | --- |
| 070_110 | 1:10–1:50 | 持续谐波及起音结构的常规对照 |
| 175_215 | 2:55–3:35 | 后半段的另一组对照 |
| 140_180 | 2:20–3:00 | 风险段，覆盖本次最强残差窗口，避免只展示较有利的片段 |

片段未做乐器专家标注，不能保证每秒都恰好两件乐器同时出现。正式全曲不增加淡入淡出；仅试听片段两端统一加 5 ms 淡变，防止截断爆音。

**音量已经匹配：** 全曲四版本均为 **{levels['full_common_target_lufs']:.1f} LUFS**；三组片段内均为 **−23.0 LUFS**。全曲为了给尖锐残差留足峰值余量而整体更轻；只调设备的总播放音量，不要逐个把某一版本额外调大。原上传文件约 −18.1 LUFS，比匹配后的参考更响，不能直接拿不同响度当音质差异。

## 2. 只读审计

| 项目 | 结果 |
| --- | --- |
| 编码 | MP3 / MPEG Layer III，约 128 kbps |
| 采样率/声道 | 44,100 Hz / 双声道 |
| 解码时长 | {audit['decoded_duration_seconds']:.6f} 秒，约 4:06.73 |
| 解码样本数 | {audit['decoded_frames']:,} 帧 |
| 样本峰值 | {audit['peak_dbfs']:.2f} dBFS；未发现接近满刻度的连续削波证据 |
| 原始响度 | FFmpeg 测得约 −18.1 LUFS，真峰值约 −0.3 dBFS |
| 左右相关性 | {audit['left_right_correlation']:.4f}，不是简单双单声道；保持立体声 |
| 直流偏移 | 左右约 {audit['dc'][0]:.6f} / {audit['dc'][1]:.6f} |
| 频谱 | 大部分能量在 500–2,000 Hz；约 9 kHz 后很弱，并有局部带宽变化 |

单凭这份 MP3 无法断定带宽损失发生于录音、先前处理还是编码的哪一步。MP3 和此前链路已经丢失的高频/细节不能恢复为真实原演奏。导出 WAV/320 kbps MP3 只是减少后续损失，不把原录音升级成真正的原始无损母带。

50/60 Hz 邻域未形成足够可信的电源嗡声证据，因此没有盲目陷波，以免削弱低音和泛音。未发现足以区分拨弦起音与故障脉冲的可靠依据，因此没有自动去点击、补波或重画频谱。

源文件 SHA-256：`{audit['source_sha256']}`。处理前后源文件哈希一致，未覆盖原文件。

## 3. A 版：实际处理

1. 12 Hz、二阶 Butterworth 高通，前后向零相位处理，仅校正直流和次声；不改变速度或音高。
2. 4096 点 STFT、1024 点步长；左右声道共用同一增益掩膜，避免独立门限导致声像漂移。
3. 以 1–239 秒的低百分位功率作保守噪声底代理，**不是经过确认的纯噪声样本**。
4. 每个时频单元最多削弱 1.5 dB；保护窄带谐波峰和短促起音，并做轻度时频平滑。
5. 不使用激励器、高频“补回”、去混响、移调、变速、压缩器或限幅器。

平均时频削弱约 {a['mean_spectral_attenuation_db']:.3f} dB。A 与原始波形相关性 {quality['A_waveform_correlation']:.6f}；主要音乐频段的整体能量改变量约 0.01 dB。直流残留降至约 4×10⁻⁸。**A 的变化刻意很小，不能承诺明显“焕新”。** 无独立噪声参考，不能把差分能量说成可靠的 SNR 提升。

## 4. 模型调研与实际可运行性

| 模型 | 能否按文字提取 | 本轮状态/选择原因 |
| --- | --- | --- |
| SAM Audio | 支持文本、视觉、时间提示 | 未运行。官方权重需 HF 访问许可；环境无令牌，HF 网络访问受阻；另无 GPU。无 GPU 不等于理论绝对不能 CPU 推理，但本轮不能取得所需权重 |
| Demucs / HTDemucs 6s | 不支持任意文本；6s 有 guitar/piano 等 | 安装了 Demucs 4.1.0 包，但 HT6 权重主机返回代理 CONNECT 403；不能宣称已运行 6s |
| TorchAudio Hybrid Demucs | 固定 drums/bass/other/vocals | **实际完整运行**，官方权重可从 PyTorch 主机取得，CPU 可运行 |
| BS/Mel-Band RoFormer | 常见检查点是人声/伴奏，不能天然按英文任意选乐器 | 已查公开配置和权重清单；未发现经验证的三弦/胡尔检查点，未运行 |
| AudioSep / CLAPSep | 支持文字提示 | 查阅了官方代码/配置；AudioSep 为 32 kHz 单声道路径，相关权重/文本编码器依赖本环境无法访问的 HF，未运行 |

本轮没有把 EQ、常规高通或谐波/打击分解伪称为 AI 乐器分离。

## 5. B 版：实际模型与参数

- 实际模型：`{ai['model']}`，Hybrid Demucs，不是未加载成功的 HTDemucs 6s，也不是 SAM。
- 实际权重：`hdemucs_high_trained.pt`，{ai['checkpoint_bytes']:,} 字节；参数 {ai['parameters']:,}。
- 权重 SHA-256：`{ai['checkpoint_sha256']}`。
- PyTorch {ai['torch']}、TorchAudio {ai['torchaudio']}，CPU 4 线程。
- 全曲 8 秒窗口、2 秒交叠，归一化 sin²/cos² 交叠相加；不逐分轨自动改音量，不做随机移位。
- 41 个推理窗口，实际耗时约 {ai['duration_processing_seconds']:.1f} 秒；全曲均经过模型。

该模型只有四类，本轮没有运行 `plucked string instrument` / `bowed string instrument` 文本提示，也没有给输出虚假标上“三弦纯轨”“胡尔纯轨”。通用 `other` 类仅作为保留器乐的近似候选。

为尽量保护原音，本轮不把神经网络估计波形直接替换成新演奏。使用真实四分轨预测生成 `P_other / ΣP_all` 软掩膜，经轻度平滑后作用于原录音的复数立体声频谱：增益只在 0–1，原相位和左右关系继续使用原录音。另做同样 12 Hz 去直流；没有补入新音符、叠加生成乐器、移调或变速。

**能力边界：** 这个模型可能把拨弦起音当作 drums，把拉弦的持续音/滑音当作 vocals；other 也可能包含非目标声音。因而 B 不是经确认的民族乐器纯分离。全局波形相关性 {quality['B_waveform_correlation']:.6f} 也不能证明每一个装饰音都被保留。

## 6. 被削弱声轨与误删检查

在响度匹配前定义 `Removed = 原始解码波形 − B`。相加恢复输入的最大样本误差为 {quality['residual_recombination_max_abs_error']:.2e}，来自浮点舍入。不是只保存被模型命名为 drums/vocals 的轨道，而是保存 B 实际改变的完整差分。

差分本身可能含弓毛摩擦、拨弦起音、泛音和其他演奏内容，**不能当作纯杂音直接丢弃**。建议重点听原时间 0:19.5、0:27.5、2:24、2:31.5 附近；第三组试听覆盖其中的强残差段。没有干净真实分轨，不能报告该曲的 SDR、分离准确率或“100% 保留”结论。

交付的 Removed 为便于检查也单独做了响度匹配。**不同匹配增益的 B 与 Removed 不能直接相加重混。** 需要先按 `音量匹配参数.json` 的 `gain_linear` 撤销各自增益，才对应原始相对电平；24-bit 量化会留下很小误差。原始浮点 B 和差分保存在工程分析文件中，可用于精确复算。

## 7. 音量匹配与验证

使用 BS.1770 K 加权的整段响度，按常数增益匹配，并重新测量门限变化；没有用压缩/限幅换取同响度。保留原动态。全曲四版均降低音量，没有把 A/B 增大以冒充改善。

| 全曲版本 | 常数增益 dB | WAV LUFS | MP3 解码 LUFS | MP3 真峰值 dBFS |
| --- | --- | --- | --- | --- |
'''
for name,v in levels['full'].items():report+=f'| {name} | {v["gain_db"]:.3f} | {v["wav_metrics"]["lufs"]:.3f} | {v["mp3_decoded_metrics"]["lufs"]:.3f} | {v["mp3_decoded_metrics"]["true_peak_dbfs_4x"]:.2f} |\n'
report+=f'''
完成 **{len(checks)} 项工程检查**：{len(manifest)} 个实际音频文件格式/采样数、四组响度匹配、MP3 解码真峰值、源哈希、残差可复算性等。WAV 组内差异小于 0.03 LU，MP3 小于 0.15 LU；全部输出解码后无削波，三组片段的 A/B 与原时间轴互相关峰均在 0 ms。

工程检查不是音质评分。没有进行民族乐器专家盲听；原音韵味、弓擦和拨弦余韵是否满意，需要以本次对照音频试听判断。当前更适合把 A 作为保守留档候选，把 B 和 Removed 留作分离试验。

## 8. 可执行的后续文字提取路线

附 `SAM_Audio_Optional_GPU_Route.ipynb` 和 `sam_prompt_route.py`。在你自己的足够显存 GPU 环境、获得 `facebook/sam-audio-small` 权重许可并可访问 HF 后运行：

1. 选择 GPU 运行时，按 Notebook 安装官方 SAM Audio。
2. 在自己的账户中登录 HF；明确取得模型访问许可。
3. 上传原录音并运行。脚本分别请求 `plucked string instrument` 和 `bowed string instrument`。
4. 对两种候选使用 max-union 掩膜，避免把共有泛音重复相加；输出联合版、两个候选和完整差分，并导出 WAV/MP3。

这些文件做了语法/命令行静态检查，**本环境没有实际运行 SAM 推理或验证 Notebook 的整个安装流程**。模型权限、网络、显存不足会报错，不会回退滤波后冒充完成。文本描述也不能保证三弦/胡尔身份准确，仍需试听残差。

## 9. 可追溯资料

- PyTorch/TorchAudio 官方模型： https://pytorch.org/audio/stable/pipelines.html#hdemucs-high-musdb-plus
- 实际权重： {ai['checkpoint_url']}
- Demucs： https://github.com/facebookresearch/demucs
- SAM Audio： https://github.com/facebookresearch/sam-audio
- RoFormer 可运行代码与权重清单： https://github.com/ZFTurbo/Music-Source-Separation-Training
- AudioSep： https://github.com/Audio-AGI/AudioSep
- CLAPSep： https://github.com/Aisaka0v0/CLAPSep

详细参数、实际依赖版本、检查日志、源谱图和复算脚本随工程资料包提供。模型文件及 Python 虚拟环境不打入资料包；实际模型权重哈希已记录。
'''
(O/'处理报告_简体中文.md').write_text(report,encoding='utf-8')
readme='''# 先听这里

先解压 Saihan_Listen_First_MP3.zip，进入 070_110 文件夹。
Original = 同响度原音参考；A = 保守修复；B = 真 AI 通用器乐近似提取；Removed = 被削弱声，可能含误删的乐器。
每个片段 40 秒，每组四个文件同为 −23 LUFS，按相同设备音量试听。
175_215 是另一段；140_180 特别覆盖强残差/风险段。

全曲均为 −27.1 LUFS，以保留尖锐残差余量，没有压缩/限幅。请提高设备总音量，不要比较不同文件时分别调大。
A 更适合保守留档。B 未完成经确认的三弦/胡尔独立纯轨，不要把 Removed 当作纯噪声直接丢弃。

每个版本在对应目录都有 WAV / MP3。WAV 为 44.1kHz 双声道 24-bit；MP3 为 320kbps，不能恢复原128kbps已经丢失的信息。
报告说明真实模型、参数、成功与失败，以及可选的 SAM GPU 路线（未在本环境运行）。
'''
(O/'先读我.txt').write_text(readme)
print('REPORT_AND_VALIDATION_READY',len(checks),'checks',len(manifest),'audio files',flush=True)
