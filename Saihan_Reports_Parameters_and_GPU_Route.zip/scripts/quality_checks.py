from pathlib import Path
import numpy as np,soundfile as sf,json,hashlib
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];x,sr=sf.read(R/'analysis/original_decoded.wav',dtype='float32',always_2d=True);A,_=sf.read(R/'analysis/A_unmatched_float.wav',dtype='float32',always_2d=True);B,_=sf.read(R/'analysis/B_unmatched_float.wav',dtype='float32',always_2d=True);D,_=sf.read(R/'analysis/B_removed_unmatched_float.wav',dtype='float32',always_2d=True)
assert x.shape==A.shape==B.shape==D.shape
def energy(v):return float(np.mean(v.astype('f8')**2))
report={'frames':len(x),'sample_rate':sr,'all_shapes_identical':True,'A_waveform_correlation':float(np.corrcoef(x.ravel(),A.ravel())[0,1]),'B_waveform_correlation':float(np.corrcoef(x.ravel(),B.ravel())[0,1]),'B_removed_signal_energy_relative_db':float(10*np.log10(energy(D)/energy(x))),'residual_recombination_max_abs_error':float(np.max(np.abs(x.astype('f8')-B.astype('f8')-D.astype('f8')))),'source_sha256_unchanged':hashlib.sha256((R/'inputs/original.mp3').read_bytes()).hexdigest()=='f5619fa8d6a8bdc5caf7119c088d50039820f620067d20ecd2179f03cc197d3a','clip_alignment':{}}
for begin,end in [(70,110),(175,215),(140,180)]:
 ref=signal.resample_poly(x[begin*sr:end*sr].mean(1),1,4)
 for name,v in [('A',A),('B',B)]:
  test=signal.resample_poly(v[begin*sr:end*sr].mean(1),1,4);corr=signal.correlate(ref,test,method='fft');mid=len(ref)-1;radius=110;peak=int(np.argmax(corr[mid-radius:mid+radius+1]))-radius;report['clip_alignment'][f'{begin}_{end}_{name}']={'best_lag_samples_at_11025Hz':peak,'best_lag_ms':peak*1000/11025}
  assert abs(peak)<=1
window=sr//2;n=len(x)//window;rs=np.sqrt(np.mean(D[:n*window].reshape(n,window,2)**2,axis=(1,2)));order=np.argsort(rs)[::-1];top=[]
for i in order:
 if all(abs(float(i*.5)-v['start_seconds'])>3 for v in top):top.append({'start_seconds':float(i*.5),'end_seconds':float(i*.5+.5),'raw_residual_rms_dbfs':float(20*np.log10(rs[i]+1e-20))})
 if len(top)==8:break
report['residual_strongest_windows_to_audition']=top
f,P=signal.welch(x.mean(1),sr,nperseg=8192);band_changes={}
for name,v in [('A',A),('B',B)]:
 _,Pv=signal.welch(v.mean(1),sr,nperseg=8192);bands={}
 for lo,hi in [(50,500),(500,2000),(2000,5000),(5000,9000)]:
  m=(f>=lo)&(f<hi);bands[f'{lo}-{hi}Hz']=float(10*np.log10((np.trapezoid(Pv[m],f[m])+1e-20)/(np.trapezoid(P[m],f[m])+1e-20)))
 band_changes[name]=bands
report['pre_gain_band_energy_change_db']=band_changes;report['quality_claim']='No reference stems: these are integrity/level checks, not ground-truth separation accuracy or SNR improvement.'
(R/'analysis/quality_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,indent=2),flush=True)
fig,axes=plt.subplots(4,1,figsize=(13,11),sharex=True,sharey=True,constrained_layout=True)
names=['Original','A_Conservative','B_AI_Other_Approximation','B_Removed_Check_For_Lost_Strings']
for ax,name,title in zip(axes,names,['Original reference, matched','A: conservative restoration, matched','B: learned other-class candidate, matched','Removed sound, separately matched for inspection']):
 v,_=sf.read(R/'output/comparisons/070_110'/f'{name}.wav',dtype='float32',always_2d=True);f,t,z=signal.stft(v.mean(1),sr,nperseg=2048,noverlap=1536);im=ax.pcolormesh(t+70,f,20*np.log10(np.abs(z)+1e-9),vmin=-85,vmax=-30,shading='auto',rasterized=True);ax.set(ylim=(0,9000),ylabel='Hz',title=title)
axes[-1].set_xlabel('Original timeline / s');fig.colorbar(im,ax=axes,label='dBFS after loudness matching',shrink=.7);fig.savefig(R/'analysis/comparison_spectrogram_070_110.png',dpi=150);plt.close(fig)
