import bpy,bmesh,importlib.util,time,json,hashlib,sys,traceback
from pathlib import Path
import numpy as np
R=Path('/workspace/artifacts/soulgrain-semantic-v2')
V1=Path('/workspace/artifacts/soulgrain-semantic-v1/tests/work-v1-verified.blend')
OUT=R/'tests/verification-v2.blend'
report={'blender':bpy.app.version_string,'platform':sys.platform,'checks':[],'timings':{},'fixture_note':'Cloud V1 regression fixture, not the user Mac work file. Deliberately mislabeled test faces are not delivered.'}
start=time.perf_counter()
def flush():
 (R/'reports/integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
def check(name,ok,detail=None):
 row={'name':name,'passed':bool(ok)}
 if detail is not None:row['detail']=detail
 report['checks'].append(row);flush();print('PASS' if ok else 'FAIL',name,detail or '',flush=True)
 assert ok,name
def timed(name,fn):
 t=time.perf_counter();val=fn();report['timings'][name]=round(time.perf_counter()-t,4);flush();print('TIME',name,report['timings'][name],flush=True);return val
def must_reject(name,fn):
 try:r=fn();ok=r=={'CANCELLED'}
 except (ValueError,RuntimeError):ok=True
 check(name,ok)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 v1sha=sha(V1);bpy.ops.wm.open_mainfile(filepath=str(V1),use_scripts=False,load_ui=False)
 spec=importlib.util.spec_from_file_location('sgo2',R/'scripts/soulgrain_semantic_v2.py');a=importlib.util.module_from_spec(spec);sys.modules['sgo2']=a;spec.loader.exec_module(a);a.register()
 check('register on V1 without changing V1 metadata','v2' not in a.meta())
 original=a.meta();before=a._annotation_hashes(original);source=Path(original['source_path']);sourcesha=sha(source);parts0=original['parts'];uids0=list(original['objects']);resources0=a.resource_signature()
 must_reject('V1 editing blocked before Save As',a.safe_work)
 must_reject('cannot upgrade over V1 path',lambda:bpy.ops.sgo_v2.upgrade_work(filepath=str(V1)))
 # Each test run uses a new destination; never overwrite the V1 fixture.
 if OUT.exists():OUT=R/'tests'/('verification-v2-'+str(time.time_ns())+'.blend')
 check('upgrade to new V2 work file',timed('upgrade_full_validation_and_save',lambda:bpy.ops.sgo_v2.upgrade_work(filepath=str(OUT)))=={'FINISHED'})
 check('V1 disk SHA preserved',sha(V1)==v1sha)
 check('all V1 labels confidence issues and source face IDs preserved',a._annotation_hashes(a.meta())==before)
 check('stable part UUIDs and object UUIDs preserved',a.meta()['parts']==parts0 and list(a.meta()['objects'])==uids0)
 r=timed('initial_cache_refresh',lambda:a.ensure_session(refresh=True));check('actual complete face statistics',sum(r.hist.values())==1499039)
 check('UPPER parent includes all upper descendants',{10,11,12,13,14,70}<=a.subtree('UPPER'))
 check('parent and exact-category controls distinct',a.subtree('UPPER::SELF')=={10} and a.subtree('UPPER')!={10})
 check('unknown controls exist',a.subtree('UNKNOWN')=={0})
 check('part counts equal actual cached face arrays',all(n['count']==sum(np.count_nonzero(np.isin(e['p'],n['codes'])) for e in r.entries.values()) for n in r.tree.values()))
 bpy.context.scene.sgo_v2_search='鞋舌';check('Chinese search finds matching hierarchy',any(row.key=='TONGUE' for row in bpy.context.scene.sgo_v2_rows) and len(bpy.context.scene.sgo_v2_rows)<len(r.tree));bpy.context.scene.sgo_v2_search=''
 icons=bpy.types.UILayout.bl_rna.functions['operator'].parameters['icon'].enum_items.keys();used=['TRIA_DOWN','TRIA_RIGHT','BLANK1','HIDE_OFF','HIDE_ON','SOLO_ON','SOLO_OFF','FACESEL','LOCKED','UNLOCKED','FILE_REFRESH','VIEWZOOM','GEOMETRY_NODES','CANCEL'];check('all UI icon names valid',all(x in icons for x in used))
 col=a.catalog()[11]['color'];png=a.palette_png(col);check('legend PNG generated from actual configured color',png[:8]==b'\x89PNG\r\n\x1a\n' and a.palette_png(a.catalog()[12]['color'])!=png)
 t=time.perf_counter();bpy.ops.sgo_v2.view_part(key='UPPER',action='TOGGLE');report['timings']['hide_upper_first_multi_edit']=round(time.perf_counter()-t,4)
 check('semantic hiding enters real multi-object edit mode',all(o.mode=='EDIT' for o in a.objects().values()))
 check('hide UPPER all descendants on actual faces',all(np.array_equal(a.hidden_array(e['object']),np.isin(e['p'],list(a.subtree('UPPER')))) for e in a.rt().entries.values()))
 timed('hide_second_component_warm',lambda:bpy.ops.sgo_v2.view_part(key='TONGUE',action='TOGGLE'))
 check('multiple hidden categories coexist',a.subtree('UPPER')|a.subtree('TONGUE')<=set(a.view_state()['hidden']))
 storedhidden=a.view_state()['hidden'].copy();timed('solo_soling',lambda:bpy.ops.sgo_v2.view_part(key='SOLING',action='SOLO'))
 check('solo shows only requested semantic family',all(np.array_equal(a.hidden_array(e['object']),~np.isin(e['p'],list(a.subtree('SOLING')))) for e in a.rt().entries.values()))
 bpy.ops.sgo_v2.view_part(action='CLEAR_SOLO');check('leaving solo restores prior multi-hide',a.view_state()['hidden']==storedhidden and a.visible_codes()==set(a.catalog())-set(storedhidden))
 check('visibility never changes ownership or other annotation attributes',a._annotation_hashes(a.meta())==before)
 bpy.ops.sgo_v2.lock_part(key='UPPER');timed('restore_all_visibility',lambda:bpy.ops.sgo.show_all());check('restore all does not unlock parts',a.subtree('UPPER')<=a.locked_codes())
 check('all face hide flags cleared',all(not a.hidden_array(o).any() for o in a.objects().values()))
 body=bpy.data.objects['Shoe_TEST_V3'];bpy.context.view_layer.objects.active=body
 e=a.get_entry(body);chosen=int(np.flatnonzero((e['p']==11)&(e['i']==0)&(e['s']!=a.HUMAN))[100]);a.set_selected_ids(body,np.array([chosen],'i4'))
 bpy.context.scene.sgo_target='12';old=a._annotation_hashes(a.meta());must_reject('manual assignment to locked target rejected',lambda:bpy.ops.sgo.assign_selected())
 bpy.context.scene.sgo_target='21';check('manual operation skips locked source faces',bpy.ops.sgo.assign_selected()=={'FINISHED'} and a._annotation_hashes(a.meta())==old)
 bpy.ops.sgo_v2.lock_part(clear_all=True)
 check('inspect one real body face',timed('inspect_single_face_multi_edit',lambda:bpy.ops.sgo_v2.inspect_selected())=={'FINISHED'})
 ins=json.loads(bpy.context.scene['_sgo_v2_inspection']);check('inspection includes object UUID part code confidence status issue and source face ID',ins['faces']==1 and ins['detail']['code']==11 and ins['detail']['object_id']==body['_sgo_object_id'] and all(k in ins['detail'] for k in ['confidence','status','issue','source_face_id']))
 second=int(np.flatnonzero((e['p']==12)&(e['i']==0))[0]);a.set_selected_ids(body,np.array([chosen,second],'i4'));bpy.ops.sgo_v2.inspect_selected();ins=json.loads(bpy.context.scene['_sgo_v2_inspection']);check('multi selection histogram accurate',ins['faces']==2 and ins['parts']=={'11':1,'12':1})
 a.set_selected_ids(body,np.array([chosen],'i4'));bpy.context.scene.sgo_target='11'
 bpy.context.scene.sgo_v2_max_faces=1000;bpy.context.scene.sgo_v2_radius=8;bpy.context.scene.sgo_v2_max_seconds=3
 pregrow=a._annotation_hashes(a.meta());check('real body growth preview',timed('first_body_graph_and_preview',lambda:bpy.ops.sgo_v2.grow_preview())=={'FINISHED'})
 pending=a.rt().pending;ix=pending['indices'].copy();report['graph']=pending['graph_info'];report['first_growth']=pending['engine'].stats();check('growth nontrivial and bounded',1<len(ix)<=1000,len(ix))
 check('preview performs zero annotation writes',a._annotation_hashes(a.meta())==pregrow)
 check('preview is real native face selection',np.array_equal(np.sort(a.selected_ids(body)),np.sort(ix)))
 bpy.ops.sgo_v2.grow_cancel();check('cancel restores seed selection and leaves labels unchanged',np.array_equal(a.selected_ids(body),[chosen]) and a._annotation_hashes(a.meta())==pregrow and a.rt().pending is None)
 timed('warm_body_growth_preview',lambda:bpy.ops.sgo_v2.grow_preview());bpy.context.scene.sgo_v2_angle=21;check('parameter change invalidates preview without writes',a.rt().pending is None and a._annotation_hashes(a.meta())==pregrow)
 bpy.ops.sgo_v2.grow_preview();ix=a.rt().pending['indices'].copy();a.set_selected_ids(body,np.array([chosen],'i4'));must_reject('confirm rejects edited candidate selection',lambda:bpy.ops.sgo_v2.grow_confirm());bpy.ops.sgo_v2.grow_cancel()
 bpy.ops.sgo_v2.grow_preview();ix=a.rt().pending['indices'].copy();prelabels=a.read_labels(body.data);check('confirm explicit growth',timed('confirm_growth_full_source_validation',lambda:bpy.ops.sgo_v2.grow_confirm())=={'FINISHED'})
 after=a.read_labels(body.data);mask=np.ones(len(after[0]),bool);mask[ix]=False
 check('only candidate faces changed on active mesh',all(np.array_equal(x[mask],y[mask]) for x,y in zip(prelabels,after)))
 check('confirmed candidates human and target class',np.all(after[0][ix]==11) and np.all(after[1][ix]==a.HUMAN))
 otherhash=a._annotation_hashes(a.meta());check('all non-target objects unchanged',all(otherhash[uid]==pregrow[uid] for uid in otherhash if uid!=body['_sgo_object_id']))
 # Check color consistency after BMesh assignment against configuration in Object Mode.
 bpy.ops.sgo.object_mode();firstloop=body.data.polygons[int(ix[0])].loop_start;actual=list(body.data.color_attributes[a.COLOR].data[firstloop].color)[:3];report['preview_color_readback']={'configured_linear':list(col),'actual_after_bmesh':actual}
 check('manual preview color matches palette within byte color precision',np.allclose(actual,col,atol=.008),report['preview_color_readback'])
 check('geometry UV normals transforms PBR textures all unchanged',bool(timed('final_full_validation_object_mode',lambda:a.validate())))
 # Verify JSON, keeping the V1 schema and stable IDs.
 payload=timed('v2_json_export_payload',a.export_payload);check('JSON V1 schema retained and not authorized for split',payload['schema']==a.SCHEMA and payload['formal_boundary_certified'] is False and payload['split_authorized'] is False)
 check('JSON compatible import preserves manual records',isinstance(timed('v2_json_roundtrip',lambda:a.import_payload(payload)),int) and a._annotation_hashes(a.meta())==otherhash)
 bpy.ops.sgo_v2.lock_part(key='TONGUE');must_reject('JSON cannot bypass locked parts',lambda:a.import_payload(payload));bpy.ops.sgo_v2.lock_part(clear_all=True)
 check('save V2 operator',timed('save_v2_work',lambda:bpy.ops.sgo.save_work())=={'FINISHED'})
 savehash=a._annotation_hashes(a.meta());v2meta=a.meta();saved_path=bpy.data.filepath
 a.unregister();a.register();check('repeat tool registration preserves annotation and UUID data',a._annotation_hashes(a.meta())==savehash)
 bpy.ops.wm.open_mainfile(filepath=saved_path,use_scripts=False,load_ui=False);a.ensure_session(refresh=True);check('reload V2 work persists annotations and IDs',a._annotation_hashes(a.meta())==savehash and a.meta()['parts']==parts0)
 check('reloaded geometry UV materials textures valid',bool(a.validate()))
 check('original model and V1 work disk hashes unchanged',sha(source)==sourcesha and sha(V1)==v1sha)
 report['original_sha256']=sourcesha;report['v1_fixture_sha256']=v1sha;report['v2_test_file']=saved_path;report['face_count']=1499039;report['mesh_objects']=13;report['seconds']=round(time.perf_counter()-start,3);report['status']='passed';flush();print('INTEGRATION_COMPLETE',flush=True)
except Exception:
 report['status']='failed';report['error']=traceback.format_exc();flush();traceback.print_exc();sys.exit(1)
