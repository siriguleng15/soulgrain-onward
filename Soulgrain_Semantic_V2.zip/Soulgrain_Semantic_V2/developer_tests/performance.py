import bpy,importlib.util,json,time,resource,sys
from pathlib import Path
import numpy as np
R=Path('/workspace/artifacts/soulgrain-semantic-v2');report={'blender':bpy.app.version_string,'platform':sys.platform,'checks':[],'measurements':{}}
def check(n,x):
 report['checks'].append({'name':n,'passed':bool(x)});print('PASS' if x else 'FAIL',n,flush=True);assert x,n
def measure(n,fn):
 t=time.perf_counter();x=fn();report['measurements'][n]=round(time.perf_counter()-t,4);print('TIME',n,report['measurements'][n],flush=True);return x
path=json.loads((R/'reports/integration.json').read_text())['v2_test_file'];bpy.ops.wm.open_mainfile(filepath=path,use_scripts=False,load_ui=False);spec=importlib.util.spec_from_file_location('sgo2_perf',R/'scripts/soulgrain_semantic_v2.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);a.register();measure('fresh_object_mode_statistics',lambda:a.ensure_session(refresh=True))
o=bpy.data.objects['Shoe_TEST_V3'];bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;measure('body_enter_edit_mode',lambda:bpy.ops.sgo.enter_face_mode());r=a.ensure_session(refresh=True);e=a.get_entry(o);eligible=np.flatnonzero((e['p']==11)&(e['i']==0)&(e['s']!=a.HUMAN));seed=int(eligible[100]);bpy.context.scene.sgo_target='11';a.set_selected_ids(o,np.array([seed],'i4'))
bpy.context.scene.sgo_v2_max_faces=50000;bpy.context.scene.sgo_v2_radius=15;bpy.context.scene.sgo_v2_max_seconds=8
check('default-limit real model preview',measure('default_50k_limit_first_preview',lambda:bpy.ops.sgo_v2.grow_preview())=={'FINISHED'});report['default_growth']=a.rt().pending['engine'].stats();report['graph']=a.rt().pending['graph_info'];a.cancel_pending()
check('default limit retained',report['default_growth']['candidateFaces']<=50000)
# Explicitly broader parameter profile, still no confirmed writes.
seeds=eligible[np.linspace(0,len(eligible)-1,8,dtype='i4')];a.set_selected_ids(o,seeds);bpy.context.scene.sgo_v2_angle=30;bpy.context.scene.sgo_v2_seed_angle=60;bpy.context.scene.sgo_v2_radius=25;bpy.context.scene.sgo_v2_max_faces=100000
snapshot=a._annotation_hashes(a.meta());check('wider multi-seed preview',measure('wide_multi_seed_warm_preview',lambda:bpy.ops.sgo_v2.grow_preview())=={'FINISHED'});report['wide_growth']=a.rt().pending['engine'].stats();a.cancel_pending();check('both previews cancel without writing',a._annotation_hashes(a.meta())==snapshot)
# Deliberately broad batch selection exercises the tool, not a semantic assertion.
a.set_selected_ids(o,eligible[:20000]);check('20k face batch assignment operator',measure('manual_batch_20000_faces',lambda:bpy.ops.sgo.assign_selected())=={'FINISHED'});check('20k faces receive HUMAN status',np.all(a.read_labels(o.data)[1][eligible[:20000]]==a.HUMAN))
check('full post-batch geometry UV normal PBR integrity',bool(measure('full_validate_in_body_edit_mode',lambda:a.validate())))
report['peak_process_rss_mib_linux']=round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,2);report['status']='passed';report['hardware']='Cloud Linux. Timings are not MacBook guarantees; RSS includes original textures, Blender and BMesh.';(R/'reports/performance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PERFORMANCE_COMPLETE',flush=True)
