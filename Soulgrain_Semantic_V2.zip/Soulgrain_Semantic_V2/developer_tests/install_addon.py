import bpy,json
from pathlib import Path
R=Path('/workspace/artifacts/soulgrain-semantic-v2')
assert bpy.ops.preferences.addon_install(filepath=str(R/'delivery/Soulgrain_Semantic_V2_Addon.zip'),overwrite=True)=={'FINISHED'}
assert bpy.ops.preferences.addon_enable(module='soulgrain_semantic_v2')=={'FINISHED'}
assert hasattr(bpy.types.Scene,'sgo_v2_rows') and hasattr(bpy.types,'SGO2_PT_manager')
assert bpy.ops.preferences.addon_disable(module='soulgrain_semantic_v2')=={'FINISHED'}
assert not hasattr(bpy.types.Scene,'sgo_v2_rows')
(R/'reports/addon-install.json').write_text(json.dumps({'blender':bpy.app.version_string,'install_from_zip':True,'enable':True,'disable':True,'preferences_saved':False,'user_script_dir':bpy.utils.user_resource('SCRIPTS')},indent=2));print('V2_ADDON_INSTALL_PASS',flush=True)
