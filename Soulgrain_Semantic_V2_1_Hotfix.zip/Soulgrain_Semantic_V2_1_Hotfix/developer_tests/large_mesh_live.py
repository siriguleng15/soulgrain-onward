import bpy,bmesh,sys,json,importlib.util,time,hashlib,traceback
from pathlib import Path
import numpy as np
R=Path('/workspace/artifacts/soulgrain-semantic-v2-1');report={'blender':bpy.app.version_string,'checks':[],'timings':{}}
def check(n,x,detail=None):
 report['checks'].append({'name':n,'passed':bool(x),'detail':detail});print('PASS' if x else 'FAIL',n,detail or '',flush=True);assert x,n
def reject(n,fn):
 try:x=fn();ok=x=={'CANCELLED'}
 except (ValueError,RuntimeError):ok=True
 check(n,ok)
def timed(n,fn):
 t=time.perf_counter();x=fn();report['timings'][n]=round(time.perf_counter()-t,4);print('TIME',n,report['timings'][n],flush=True);return x
try:
 source=Path('/workspace/artifacts/soulgrain-semantic-v2/tests/verification-v2.blend');disksha=hashlib.sha256(source.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(source),use_scripts=False,load_ui=False)
 spec=importlib.util.spec_from_file_location('live_v21',R/'scripts/soulgrain_semantic_v2_1.py');a=importlib.util.module_from_spec(spec);sys.modules['live_v21']=a;spec.loader.exec_module(a);a.register();a.ensure_session(refresh=True)
 def body():return bpy.data.objects['Shoe_TEST_V3']
 oldcolors=a.array(body().data.color_attributes[a.COLOR].data,'color',4,'f4');oldlabels=a.read_labels(body().data)
 bpy.ops.object.select_all(action='DESELECT');body().select_set(True);bpy.context.view_layer.objects.active=body();bpy.context.scene.sgo_object=body()['_sgo_object_id'];bpy.ops.sgo.enter_face_mode();e=a.get_entry(body());seed=int(np.flatnonzero((e['p']==11)&(e['s']!=a.HUMAN)&(e['i']==0))[100]);bpy.context.scene.sgo_target='11';bpy.context.scene.sgo_v2_max_faces=1000;bpy.context.scene.sgo_v2_radius=15
 a.set_selected_ids(body(),np.array([seed],'i4'));check('million-face body preview',timed('first_body_preview',lambda:bpy.ops.sgo_v2.grow_preview())=={'FINISHED'});p=a.rt().pending;orig=p['indices'].copy();check('body candidate set nontrivial',len(orig)>10,len(orig))
 valid_extra=np.flatnonzero((e['p']==0)&(e['s']!=a.HUMAN)&(e['i']==0)&~np.isin(np.arange(len(e['p'])),orig))[-3:]
 final=np.r_[orig[::2],valid_extra];a.set_selected_ids(body(),final);p['next_poll']=0;timed('automatic_timer_poll_trim_plus_add',a._mode_guard);stats=p['edit_stats'];check('timer updates retained excluded and supplemented live counts',stats['retained']==len(orig[::2]) and stats['added']==3 and stats['excluded']==len(orig)-len(orig[::2]))
 # Change selection with the same face count: count-only polling is insufficient.
 bpy.context.scene.sgo_v21_accept_added=True;alt=np.flatnonzero((e['p']==0)&(e['s']!=a.HUMAN)&(e['i']==0)&~np.isin(np.arange(len(e['p'])),np.r_[orig,valid_extra]))[-3:];a.set_selected_ids(body(),np.r_[orig[::2],alt]);p['next_poll']=0;a._mode_guard();check('automatic poll detects equal-count selection replacement',p['review_signature'] is None and not bpy.context.scene.sgo_v21_accept_added)
 # Native large supplements remain preview-only; measure statistics, not an approved region.
 large=np.flatnonzero((e['s']!=a.HUMAN)&(e['i']==0))[:20000];a.set_selected_ids(body(),large);timed('poll_20000_selected_faces',lambda:a.refresh_preview_selection(force=True));check('large manual edits counted without recalculation',p['edit_stats']['final']==20000)
 huge=np.arange(200001,dtype='i4');a.set_selected_ids(body(),huge);a.refresh_preview_selection(force=True);reject('manual supplementation cannot bypass final safety cap',lambda:bpy.ops.sgo_v2.grow_confirm());check('oversized reject leaves labels unchanged',all(np.array_equal(x,y) for x,y in zip(a.read_labels(body().data),oldlabels)))
 # Draw new warning rows with actual pending state; this is a contract test, not GUI rendering.
 class L:
  def __getattr__(self,n):
   if n in ['row','column','box','split']:return lambda *x,**kw:L()
   if n=='operator':return lambda *x,**kw:type('Props',(),{})()
   return lambda *x,**kw:None
 a.SGO2_PT_growth.draw(type('P',(),{'layout':L()})(),bpy.context);check('editable-preview panel warning draw callback',True)
 bpy.ops.sgo_v2.grow_cancel();check('large preview cancel restores seed and zero ownership writes',np.array_equal(a.selected_ids(body()),[seed]) and all(np.array_equal(x,y) for x,y in zip(a.read_labels(body().data),oldlabels)))
 a.set_selected_ids(body(),np.array([seed],'i4'));bpy.ops.sgo_v2.grow_preview();p=a.rt().pending;kept=p['indices'][::2].copy();a.set_selected_ids(body(),kept);a.refresh_preview_selection(force=True);bpy.ops.ed.undo_push(message='before real body trimmed commit');check('million-face body trimmed confirmation',timed('confirm_trimmed_body',lambda:bpy.ops.sgo_v2.grow_confirm())=={'FINISHED'});bpy.ops.ed.undo_push(message='after real body trimmed commit')
 bpy.ops.ed.undo();check('body trimmed confirmation native undo',all(np.array_equal(x,y) for x,y in zip(a.read_labels(body().data),oldlabels)));bpy.ops.ed.redo();check('body trimmed confirmation native redo',np.all(a.read_labels(body().data)[1][kept]==a.HUMAN))
 bpy.ops.object.mode_set(mode='OBJECT');after=a.read_labels(body().data);mask=np.ones(len(after[0]),bool);mask[kept]=False;check('all nonretained body labels remain byte-identical',all(np.array_equal(x[mask],y[mask]) for x,y in zip(after,oldlabels)))
 newcolors=a.array(body().data.color_attributes[a.COLOR].data,'color',4,'f4');loopmask=np.repeat(mask,a.array(body().data.polygons,'loop_total'));check('all nonretained body preview colors remain identical',np.array_equal(newcolors[loopmask],oldcolors[loopmask]))
 check('final geometry topology UV normals face IDs and PBR validate',bool(a.validate()));check('legacy V2 input file not overwritten',hashlib.sha256(source.read_bytes()).hexdigest()==disksha)
 report.update(status='passed',body_faces=len(body().data.polygons),polling='Actual _mode_guard timer callback invoked in background; GUI scheduling and physical mouse gestures require Mac acceptance.')
except Exception:
 report['status']='failed';report['error']=traceback.format_exc();traceback.print_exc()
(R/'reports/large-mesh-live.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('LARGE_MESH_COMPLETE',report['status'],flush=True)
