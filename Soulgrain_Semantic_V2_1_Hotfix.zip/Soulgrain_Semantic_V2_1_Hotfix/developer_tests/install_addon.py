import bpy,json
from pathlib import Path
R=Path('/workspace/artifacts/soulgrain-semantic-v2-1');checks=[]
def check(n,x):checks.append({'name':n,'passed':bool(x)});assert x,n;print('PASS',n,flush=True)
check('install V2.1 addon ZIP',bpy.ops.preferences.addon_install(filepath=str(R/'delivery/Soulgrain_Semantic_V2_1_Addon.zip'),overwrite=True)=={'FINISHED'})
check('enable V2.1 in restricted addon context',bpy.ops.preferences.addon_enable(module='soulgrain_semantic_v2_1')=={'FINISHED'})
check('V2.1 UI property registered',hasattr(bpy.types.Scene,'sgo_v21_accept_added'))
check('disable cleans V2.1 properties',bpy.ops.preferences.addon_disable(module='soulgrain_semantic_v2_1')=={'FINISHED'} and not hasattr(bpy.types.Scene,'sgo_v21_accept_added'))
(R/'reports/addon-install.json').write_text(json.dumps({'blender':bpy.app.version_string,'checks':checks,'status':'passed','preferences_saved':False},indent=2));print('V21_ADDON_INSTALL_COMPLETE',flush=True)
