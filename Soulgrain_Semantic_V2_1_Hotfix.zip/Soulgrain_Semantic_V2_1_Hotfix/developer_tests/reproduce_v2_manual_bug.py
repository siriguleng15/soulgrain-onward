import bpy,bmesh,importlib.util,json,sys
from pathlib import Path
import numpy as np
R=Path('/workspace/artifacts/soulgrain-semantic-v2-1');report={}
src=Path('/workspace/artifacts/soulgrain-semantic-v2/tests/verification-v2.blend');bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False,load_ui=False)
spec=importlib.util.spec_from_file_location('old_v2',Path('/workspace/artifacts/soulgrain-semantic-v2/scripts/soulgrain_semantic_v2.py'));a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);a.register();a.ensure_session(refresh=True)
body=bpy.data.objects['Shoe_TEST_V3'];eye=bpy.data.objects['New_minus_eyelet_2'];bpy.ops.object.select_all(action='DESELECT');body.select_set(True);eye.select_set(True);bpy.context.view_layer.objects.active=body;bpy.ops.object.mode_set(mode='EDIT');bpy.context.tool_settings.mesh_select_mode=(False,False,True)
pp,ss,cc,ii=a.read_labels(body.data);ix=np.flatnonzero((pp==0)&(ii==0))[:15];a.set_selected_ids(body,ix);a.set_selected_ids(eye,np.empty(0,'i4'))
# State mirrors the reported 15 manually confirmed UNKNOWN faces.
assert bpy.ops.sgo.assign_selected(unknown=True)=={'FINISHED'};bpy.ops.sgo_v2.inspect_selected();report['inspection_before']=json.loads(bpy.context.scene['_sgo_v2_inspection'])
last=bpy.context.window_manager.operator_properties_last('sgo.assign_selected');report['python_call_stored_last_properties']=bool(last.unknown)
# Python calls deliberately do not store WM UI history. Emulate the actual previous UI action.
last.unknown=True;report['last_unknown_after_unknown_ui_payload']=bool(last.unknown)
bpy.context.scene.sgo_target='10';a.set_selected_ids(eye,np.arange(23,dtype='i4'))
# Explicitly replay the last-properties payload that the old normal UI button does not override.
assert bpy.ops.sgo.assign_selected(unknown=last.unknown)=={'FINISHED'}
report['success_message']=bpy.context.scene.sgo_message;report['actual_body_labels']=a.read_labels(body.data)[0][ix].tolist();report['actual_eye_labels']=a.read_labels(eye.data)[0][:23].tolist();report['inspection_after']=json.loads(bpy.context.scene['_sgo_v2_inspection'])
report['blender']=bpy.app.version_string;report['ui_history_replayed']=True;report['physical_gui_click_tested']=False
(R/'reports/v2-root-cause-reproduction.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
assert report['inspection_before']['faces']==15 and '38' in report['success_message'] and report['actual_body_labels']==[0]*15 and report['inspection_after']==report['inspection_before']
# With unknown explicitly false, BMesh storage itself writes and persists real UPPER values.
assert bpy.ops.sgo.assign_selected(unknown=False)=={'FINISHED'};report['explicit_false_actual_body_labels']=a.read_labels(body.data)[0][ix].tolist();assert report['explicit_false_actual_body_labels']==[10]*15
(R/'reports/v2-root-cause-reproduction.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('LEGACY_BUG_REPRODUCED',report['success_message'],flush=True)
