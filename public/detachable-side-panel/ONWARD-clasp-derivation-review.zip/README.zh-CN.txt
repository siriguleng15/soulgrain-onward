SoulGrain ONWARD 扣件推导与同片正反面追踪
web/ 为相对路径静态页面，可通过静态 HTTP 托管访问 detachable-side.html；iPad 可直接访问在线预览，无需开发环境。
新增扣件推导、PU动态、覆盖与编号在网页的可编辑 TypeScript 源码和 clasp-derivation.json 中。
已确认的 GLB/Blender 是上一轮纯侧片工程，不包含本轮新增扣件动态，文件下载标签已区分。
新增双面定位 SVG、JSON 与验证、19秒实际网页网格过程视频在 web/detachable-side-panel/ 中。
source/ 保存相关源码；完整仓库位于 https://github.com/siriguleng15/soulgrain-onward/tree/feat/onward-clasp-derivation 。重建所需原数据以仓库为准。
覆盖为当前假设曲面上的设计投影，工厂接触、PU宽度、重叠、公母朝向和裁切长度尚未确认。12mm只为扣外观预设。未进行iPad Safari实机测试。
