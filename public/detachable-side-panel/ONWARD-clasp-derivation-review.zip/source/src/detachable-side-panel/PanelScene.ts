import {BufferAttribute,BufferGeometry,Color,DoubleSide,FrontSide,Group,LineSegments,LineBasicMaterial,Mesh,MeshBasicMaterial,MeshStandardMaterial,Raycaster,Triangle,Vector2,Vector3,Box3,DynamicDrawUsage} from 'three';
import {ModelScene} from '../reference-model/Scene.ts';
import type {PatternData,Vec2} from '../pattern-engineering/types.ts';
import type {PanelData,PanelSelection} from './data.ts';
import {PanelEvaluator} from './timeline.ts';
import {HardwareLayer} from './HardwareLayer.ts';
import type {PhotoReg,ClaspPhotoData,HardwareVisibility} from './HardwareLayer.ts';
import type {ClaspDerivationLayer} from './ClaspDerivationLayer.ts';
export class PanelScene {
 readonly base:ModelScene;readonly evaluator:PanelEvaluator;readonly panel:Mesh<BufferGeometry,MeshStandardMaterial>;readonly wire:Mesh<BufferGeometry,MeshBasicMaterial>;
 readonly trimBand:Mesh<BufferGeometry,MeshBasicMaterial>;readonly group=new Group();
 private seams:LineSegments<BufferGeometry,LineBasicMaterial>;private boundary:LineSegments<BufferGeometry,LineBasicMaterial>;
 private seamPairs:{ids:[number,number,number];bary:[number,number,number]}[]=[];private boundaryPairs:number[]=[];
 private readonly modelBounds=new Box3();private activeIds:number[];private marker?:PanelSelection;private confidenceShown=false;private progress=0;private showSeams=true;private frozenCamera=false;private resize:ResizeObserver;
 private pointers=new Map<number,{x:number;y:number;moved:boolean}>();private down=(e:PointerEvent)=>{if(this.pointers.size)for(const p of this.pointers.values())p.moved=true;this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,moved:this.pointers.size>0});};
 private move=(e:PointerEvent)=>{const p=this.pointers.get(e.pointerId);if(p&&Math.hypot(e.clientX-p.x,e.clientY-p.y)>5)p.moved=true;};
 private up=(e:PointerEvent)=>{const p=this.pointers.get(e.pointerId),pick=p&&!p.moved&&this.pointers.size===1;this.pointers.delete(e.pointerId);if(!pick)return;const r=this.base.canvas().getBoundingClientRect(),ray=new Raycaster();ray.setFromCamera(new Vector2((e.clientX-r.x)/r.width*2-1,-(e.clientY-r.y)/r.height*2+1),this.base.camera);this.panel.updateMatrixWorld();const h=ray.intersectObject(this.panel,false)[0];if(!h||h.faceIndex==null)return;const index=this.panel.geometry.index!,attr=this.panel.geometry.getAttribute('position'),ids=[0,1,2].map(k=>index.getX(h.faceIndex!*3+k)) as[number,number,number],b=new Triangle(...ids.map(id=>new Vector3().fromBufferAttribute(attr,id)) as[Vector3,Vector3,Vector3]).getBarycoord(h.point,new Vector3());if(b)this.select({triangle:h.faceIndex,barycentric:[b.x,b.y,b.z],flatMm:[ids.reduce((s,id,i)=>s+this.data.flatMm[id*2]*[b.x,b.y,b.z][i],0),ids.reduce((s,id,i)=>s+this.data.flatMm[id*2+1]*[b.x,b.y,b.z][i],0)],vertexIds:ids.map(id=>this.data.vertexIds[id]),confidence:ids.map(id=>this.data.confidence[id])});};
 private cancel=(e:PointerEvent)=>this.pointers.delete(e.pointerId);
 constructor(readonly host:HTMLElement,readonly data:PanelData,readonly pattern:PatternData,readonly onSelection:(selection:PanelSelection)=>void,readonly onError:(message:string)=>void,readonly hardwareReference?:{registration:PhotoReg;design:ClaspPhotoData;visibility?:HardwareVisibility}){
  this.base=new ModelScene(host,{onError});this.evaluator=new PanelEvaluator(data);this.activeIds=[...new Set(data.trimmedIndices??data.indices)];const geometry=new BufferGeometry();geometry.setAttribute('position',new BufferAttribute(new Float32Array(data.formedPositions),3).setUsage(DynamicDrawUsage));geometry.setIndex(data.trimmedIndices??data.indices);geometry.computeVertexNormals();
  const color=new Float32Array(data.flatMm.length/2*3);geometry.setAttribute('color',new BufferAttribute(color,3));
  this.panel=new Mesh(geometry,new MeshStandardMaterial({color:0x204e73,roughness:.83,metalness:.02,side:DoubleSide,polygonOffset:true,polygonOffsetFactor:1,polygonOffsetUnits:1}));this.panel.name='ONWARD_RealPattern_DetachableSide';this.panel.frustumCulled=false;
  this.wire=new Mesh(geometry,new MeshBasicMaterial({color:0xc7e6ef,wireframe:true,transparent:true,opacity:.2,side:DoubleSide,depthWrite:false}));this.wire.visible=false;this.wire.frustumCulled=false;this.wire.renderOrder=2;
  const excluded=new BufferGeometry();excluded.setAttribute('position',geometry.getAttribute('position'));excluded.setIndex(data.excludedIndices);this.trimBand=new Mesh(excluded,new MeshBasicMaterial({color:0xd5a16a,transparent:true,opacity:.16,side:DoubleSide,depthWrite:false,wireframe:true}));this.trimBand.frustumCulled=false;this.trimBand.name='SoleCovered_Excluded_Band';
  this.boundaryPairs=this.findBoundary(data.trimmedIndices??data.indices);this.boundary=new LineSegments(new BufferGeometry(),new LineBasicMaterial({color:0x173d61,transparent:true,opacity:.8}));this.boundary.frustumCulled=false;
  this.seams=new LineSegments(new BufferGeometry(),new LineBasicMaterial({color:0xc9c1a9,transparent:true,opacity:.9}));this.seams.frustumCulled=false;
  this.buildSeams();
  this.group.add(this.panel,this.wire,this.trimBand,this.seams,this.boundary);this.base.scene.add(this.group);this.updateColors();this.setProgress(0,false);
  const c=this.base.canvas();c.addEventListener('pointerdown',this.down);c.addEventListener('pointermove',this.move);c.addEventListener('pointerup',this.up);c.addEventListener('pointercancel',this.cancel);
  this.resize=new ResizeObserver(()=>requestAnimationFrame(()=>{if(!this.frozenCamera)this.frameCamera();}));this.resize.observe(host);
 }
 async load(url:string){this.hardware?.dispose();this.hardware=undefined;await this.base.load(url);if(this.base.asset&&this.hardwareReference){this.hardware=new HardwareLayer(this.base.asset,this.hardwareReference.registration,this.hardwareReference.design,this.hardwareReference.visibility);this.base.scene.add(this.hardware.group);}this.base.asset?.traverse(node=>{if(node instanceof Mesh)for(const material of Array.isArray(node.material)?node.material:[node.material]){material.side=FrontSide;material.needsUpdate=true;}});const raw=this.data.replacementMask??{},replacement=Array.isArray(raw)?Object.fromEntries(raw.map(m=>[m.meshPath,m.removedTriangles])):raw;let removed=0;const visit=(node:Group|Mesh,path:string)=>{if(node instanceof Mesh){const mask=replacement[path]??replacement[node.name];if(mask?.length){const drop=new Set(mask),old=node.geometry.getIndex();if(old){const keep:number[]=[];for(let t=0;t<old.count/3;t++)if(!drop.has(t))keep.push(old.getX(t*3),old.getX(t*3+1),old.getX(t*3+2));node.geometry=node.geometry.clone();node.geometry.setIndex(keep);node.geometry.computeBoundingSphere();removed+=drop.size;}}}node.children.forEach((child,i)=>visit(child as Group|Mesh,path+'/'+i));};if(this.base.asset)visit(this.base.asset,'root');this.removedTriangles=removed;if(this.base.asset)this.modelBounds.setFromObject(this.base.asset);this.frameCamera();this.base.invalidate();return removed;}
 hardware?:HardwareLayer;private hardwareShown=false;
 derivation?:ClaspDerivationLayer;private derivationFocus=0;
 setDerivationLayer(layer:ClaspDerivationLayer){this.derivation?.dispose();this.derivation=layer;this.group.add(layer.group);layer.updateSurface(this.panel.geometry.getAttribute('position').array,this.progress);this.base.invalidate();}
 setHardwareVisible(show:boolean){this.hardwareShown=show;this.hardware?.setProgress(this.progress);if(this.hardware)this.hardware.group.visible=show&&this.progress<.24;this.base.invalidate();}
 removedTriangles=0;
 setTrimVariant(indices:number[],excludedIndices:number[],sourceTriangleIds:number[]){this.data.indices=indices;this.data.trimmedIndices=indices;this.data.excludedIndices=excludedIndices;this.data.sourceTriangleIds=sourceTriangleIds;this.panel.geometry.setIndex(indices);this.trimBand.geometry.setIndex(excludedIndices);this.activeIds=[...new Set(indices)];this.boundaryPairs=this.findBoundary(indices);this.buildSeams();this.marker=undefined;this.base.markers([]);this.setProgress(this.progress);}

 private buildSeams(){
  this.seamPairs=[];
  // Reference lines may start outside the cut edge. Sample each paper segment
  // before mapping, so an outside endpoint cannot discard its interior part.
  for(const line of this.pattern.structureLines){let last:ReturnType<PanelScene['findFlat']>;
   for(let j=1;j<line.points.length;j++){const a=line.points[j-1],b=line.points[j],steps=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/2));
    for(let k=j===1?0:1;k<=steps;k++){const t=k/steps,next=this.findFlat([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]);if(last&&next)this.seamPairs.push(last,next);last=next;}
   }
  }
 }

 private findBoundary(indices:number[]){const edges=new Map<string,{a:number;b:number;count:number}>();for(let i=0;i<indices.length;i+=3)for(let k=0;k<3;k++){const a=indices[i+k],b=indices[i+(k+1)%3],key=a<b?`${a}:${b}`:`${b}:${a}`,old=edges.get(key);if(old)old.count++;else edges.set(key,{a,b,count:1});}return[...edges.values()].filter(e=>e.count===1).flatMap(e=>[e.a,e.b]);}
 findFlat(point:Vec2){const ids=this.data.trimmedIndices??this.data.indices,p=this.data.flatMm;for(let t=0;t<ids.length;t+=3){const a=ids[t],b=ids[t+1],c=ids[t+2],ax=p[a*2],ay=p[a*2+1],bx=p[b*2],by=p[b*2+1],cx=p[c*2],cy=p[c*2+1],den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy);if(Math.abs(den)<1e-12)continue;const u=((by-cy)*(point[0]-cx)+(cx-bx)*(point[1]-cy))/den,v=((cy-ay)*(point[0]-cx)+(ax-cx)*(point[1]-cy))/den,w=1-u-v;if(Math.min(u,v,w)>=-1e-7)return{ids:[a,b,c]as[number,number,number],bary:[u,v,w]as[number,number,number],triangle:t/3};}return undefined;}
 selectFlat(point:Vec2){const f=this.findFlat(point);if(!f)return false;this.select({triangle:f.triangle,barycentric:f.bary,flatMm:[point[0],point[1]],vertexIds:f.ids.map(id=>this.data.vertexIds[id]),confidence:f.ids.map(id=>this.data.confidence[id])});return true;}
 select(selection:PanelSelection){this.marker=selection;this.updateMarker();this.onSelection(selection);}
 clearSelection(){this.marker=undefined;this.base.markers([]);this.base.invalidate();}
 private updateMarker(){if(!this.marker){this.base.markers([]);return;}const ids=this.data.trimmedIndices??this.data.indices,p=this.panel.geometry.getAttribute('position'),t=this.marker.triangle,xyz=[0,1,2].map(axis=>[0,1,2].reduce((s,k)=>s+p.array[ids[t*3+k]*3+axis]*this.marker!.barycentric[k],0)) as[number,number,number];this.base.markers([{position:xyz,color:'#e5ab55',radius:.013}]);}
 private updateLine(line:LineSegments,values:number[]){let attr=line.geometry.getAttribute('position')as BufferAttribute|undefined;if(!attr||attr.count*3!==values.length){line.geometry.setAttribute('position',new BufferAttribute(new Float32Array(values),3));attr=line.geometry.getAttribute('position')as BufferAttribute;}else{(attr.array as Float32Array).set(values);attr.needsUpdate=true;}line.geometry.computeBoundingSphere();}
 setProgress(value:number,frame=true){if(!Number.isFinite(value))throw Error('展开进度必须是有限数值。');this.progress=Math.max(0,Math.min(1,value));this.hardware?.setProgress(this.progress);if(this.hardware)this.hardware.group.visible=this.hardwareShown&&this.progress<.24;const state=this.evaluator.evaluate(this.progress),attr=this.panel.geometry.getAttribute('position')as BufferAttribute;(attr.array as Float32Array).set(state.positions);attr.needsUpdate=true;this.panel.geometry.computeVertexNormals();this.updateLine(this.boundary,this.boundaryPairs.flatMap(id=>[state.positions[id*3],state.positions[id*3+1],state.positions[id*3+2]]));this.updateLine(this.seams,this.seamPairs.flatMap(q=>[0,1,2].map(axis=>q.ids.reduce((s,id,k)=>s+state.positions[id*3+axis]*q.bary[k],0))));this.seams.visible=this.showSeams;this.trimBand.visible=this.progress>.12&&this.bandShown;this.updateMarker();this.derivation?.updateSurface(state.positions,this.progress);if(frame&&!this.frozenCamera){if(this.derivation)this.frameDerivationCamera(this.derivationFocus);else this.frameCamera();}this.base.invalidate();return state;}
 bandShown=false;
 setBandVisible(show:boolean){this.bandShown=show;this.trimBand.visible=show&&this.progress>.12;this.base.invalidate();}
 setWire(show:boolean){this.wire.visible=show;this.base.invalidate();}
 setSeams(show:boolean){this.showSeams=show;this.seams.visible=show;this.base.invalidate();}
 setConfidence(show:boolean){this.confidenceShown=show;this.updateColors();this.base.invalidate();}
 private updateColors(){const attr=this.panel.geometry.getAttribute('color')as BufferAttribute;for(let i=0;i<attr.count;i++){const confidence=this.data.confidence[i],c=new Color(this.data.observedMask[i]?'#258aa0':/smooth|derived|interpolated/.test(confidence)?'#315d86':/sole|wrap/.test(confidence)?'#cf9d67':'#917354');attr.setXYZ(i,c.r,c.g,c.b);}attr.needsUpdate=true;this.panel.material.vertexColors=this.confidenceShown;this.panel.material.color.set(this.confidenceShown?0xffffff:0x204e73);this.panel.material.needsUpdate=true;}
 frameCamera(preset:'side'|'quarter'|'top'|'paper'|'paper-back'='side'){
  const bounds=this.modelBounds.clone();const positions=this.panel.geometry.getAttribute('position'),point=new Vector3();for(const id of this.activeIds)bounds.expandByPoint(point.fromBufferAttribute(positions,id));const center=bounds.getCenter(new Vector3()),camera=this.base.camera;
  const paperView=preset==='paper'||preset==='paper-back';const direction=preset==='quarter'?new Vector3(-.35,.22,1).normalize():preset==='top'?new Vector3(0,1,.001).normalize():paperView?new Vector3(this.data.flatDisplayMatrix?.[8]??0,this.data.flatDisplayMatrix?.[9]??0,this.data.flatDisplayMatrix?.[10]??-1).normalize().multiplyScalar(preset==='paper-back'?1:-1):new Vector3(0,.05,1).normalize();camera.up.set(0,1,0);if(preset==='top')camera.up.set(0,0,-1);if(paperView)camera.up.set(this.data.flatDisplayMatrix?.[4]??0,this.data.flatDisplayMatrix?.[5]??1,this.data.flatDisplayMatrix?.[6]??0).normalize();camera.position.copy(center).addScaledVector(direction,12);camera.lookAt(center);camera.updateMatrixWorld();this.base.controls.target.copy(center);camera.zoom=1;
  const local=bounds.clone(),corners=[];for(const x of[local.min.x,local.max.x])for(const y of[local.min.y,local.max.y])for(const z of[local.min.z,local.max.z])corners.push(new Vector3(x,y,z).applyMatrix4(camera.matrixWorldInverse));const r=this.host.getBoundingClientRect(),aspect=Math.max(.1,r.width/Math.max(1,r.height));let h=Math.max(...corners.map(p=>p.y))-Math.min(...corners.map(p=>p.y)),w=Math.max(...corners.map(p=>p.x))-Math.min(...corners.map(p=>p.x));h=Math.max(h,w/aspect)*1.16;w=h*aspect;camera.left=-w/2;camera.right=w/2;camera.top=h/2;camera.bottom=-h/2;camera.updateProjectionMatrix();this.base.controls.update();this.base.invalidate();
 }
 setCamera(preset:'side'|'quarter'|'top'|'paper'|'paper-back'){this.frozenCamera=true;this.frameCamera(preset);}
 frameDerivationCamera(progress:number){
  this.derivationFocus=progress;if(this.frozenCamera||!this.derivation)return;
  this.frameCamera('side');
  const bounds=new Box3(),positions=this.panel.geometry.getAttribute('position'),point=new Vector3();
  for(const clasp of this.derivation.data.clasps)for(const sample of[clasp.bodyEndSurface,clasp.cuffEndSurface,clasp.cuffSurface]){
   point.set(0,0,0);for(let k=0;k<3;k++)point.addScaledVector(new Vector3().fromBufferAttribute(positions,sample.ids[k]),sample.barycentric[k]);bounds.expandByPoint(point);
  }
  const t=Math.max(0,Math.min(1,(progress-.06)/.22)),u=Math.max(0,Math.min(1,this.progress/.24)),focus=t*t*(3-2*t)*(1-u*u*(3-2*u)),center=bounds.getCenter(new Vector3());
  const delta=center.sub(this.base.controls.target).multiplyScalar(.9*focus);
  this.base.camera.position.add(delta);this.base.controls.target.add(delta);this.base.camera.zoom=1+.55*focus;
  this.base.camera.updateProjectionMatrix();this.base.controls.update();this.base.invalidate();
 }
 setAutoCamera(show:boolean){this.frozenCamera=!show;if(show){if(this.derivation)this.frameDerivationCamera(this.derivationFocus);else this.frameCamera();}}
 flatError(){let max=0;const state=this.evaluator.evaluate(this.progress);if(state.formedAmount!==0)return null;for(let i=0;i<state.canonicalPositions.length;i++)max=Math.max(max,Math.abs(state.canonicalPositions[i]-this.data.flatDisplayPositions[i]));return max/this.data.display.mmToModelScale;}
 getGeometryState(){return{geometryUUID:this.panel.geometry.uuid,indexCount:this.panel.geometry.index!.count,vertexIds:this.data.vertexIds,indices:Array.from(this.panel.geometry.index!.array),positions:Array.from(this.panel.geometry.getAttribute('position').array),canonicalPositions:Array.from(this.evaluator.raw),translation:[...this.evaluator.translation],progress:this.progress,flatMm:this.data.flatMm};}
 dispose(){this.derivation?.dispose();this.hardware?.dispose();this.resize.disconnect();const c=this.base.canvas();c.removeEventListener('pointerdown',this.down);c.removeEventListener('pointermove',this.move);c.removeEventListener('pointerup',this.up);c.removeEventListener('pointercancel',this.cancel);this.panel.geometry.dispose();this.panel.material.dispose();this.wire.material.dispose();this.trimBand.geometry.dispose();this.trimBand.material.dispose();this.seams.geometry.dispose();this.seams.material.dispose();this.boundary.geometry.dispose();this.boundary.material.dispose();this.base.dispose();}
}
