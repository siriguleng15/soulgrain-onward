SoulGrain ONWARD · 真实裁片工程研究 V1

在线预览：https://siriguleng15.github.io/soulgrain-onward/onward-pattern/pattern-lab.html

本包是工程研究，不是生产定稿。蓝色扣心按用户确认：第五段圆弧对应完整圆的圆心。

web/ 是独立静态网页，上传任何 HTTP(S) 静态托管即可使用。请通过 HTTP 服务打开，浏览器直接用 file:// 打开会限制 JSON/纹理请求。
source/ 是可编辑源码与计算脚本。完整仓库分支：feat/onward-pattern-engineering。
source/ 内开发时，将 web/pattern-engineering/ 复制为 source/public/pattern-engineering/，npm ci 后使用 npm run dev，打开 /pattern-lab.html。
独立构建：node scripts/build-pattern-preview.mjs /tmp/onward-pattern-preview ./
几何重算需 Node24；原图数字化另需 Python、NumPy、SciPy、Pillow、OpenCV。

web/pattern-engineering/exports/：默认假设下的裁片定位 SVG、工程 JSON、毫米 CSV。
web/pattern-engineering/data/：原始毫米裁片、标定矩阵、各阶段校验记录。
web/pattern-engineering/references/：12 张原图与 SHA256。
web/pattern-engineering/verification/：Chromium 触控模拟截图与测试记录。
source/research/pattern-engineering/：研究说明、验证范围、工厂实测清单。

局限：底部绷帮边、完整成鞋轮廓、隐藏缝合仍未还原。PU宽度、搭接量、公母扣安装孔及缝份未确定；表面扣心投影不等于PU安装孔。没有真实 iPad Safari 或工厂实物验收。软件 WebGL 动画存在长帧，不能承诺实机流畅。
