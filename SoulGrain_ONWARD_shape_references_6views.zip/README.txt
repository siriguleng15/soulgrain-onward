SoulGrain ONWARD — V3 structure-only modeling references

These 6 photos are STRUCTURE REFERENCES ONLY, from a separate retail shoe.
Do NOT reproduce its logos, surface graphics, brand text, colors or accessories.
Do NOT treat any photo as the user's final ONWARD design.

Files:
- 01_side_toe_left.jpg: Side view, toe points left; folded cuff and tongue
- 02_side_toe_right.jpg: Opposite side view, toe points right; folded cuff
- 03_front_three_quarter.jpg: Front three-quarter paired view
- 04_extended_tongue.jpg: Front three-quarter with tongue/collar extended
- 05_top_front_view.jpg: Top/front paired view showing collar opening
- 06_rear_heels.jpg: Rear view of heels and folded collar

Required geometry: high-top canvas shoe base, rubber toe cap and sole; oversized fold-down tongue; independent padded fold-down ankle cuff; eyelets and laces; heel/back seam.
Not in scope now: Mongolian spherical clasp, final print/color, crystal details, brand logo.
Do not claim this input provides orthographic calibrated dimensions; fit from multiple approximate views, flag remaining uncertainties.
If modifying existing Sketchfab CC BY model, preserve credit in website + project notes.

Suggested GitHub destination: references/shape/ (separate from public/ so retail photos are not published as website assets).
