"""Usage: python3 verify_geometry_independent.py original-A.glb test.glb"""
from pathlib import Path
import sys,json,struct,hashlib,numpy as np

def read(path):
 raw=Path(path).read_bytes();assert raw[:4]==b'glTF';assert struct.unpack_from('<I',raw,8)[0]==len(raw);size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);assert raw[24+size:28+size]==b'BIN\0';binary=memoryview(raw)[28+size:]
 def array(i):
  a=doc['accessors'][i];b=doc['bufferViews'][a['bufferView']];dtype=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);width={'VEC3':3,'SCALAR':1}[a['type']];return np.ndarray((a['count'],width),dtype=dtype,buffer=binary,offset=b.get('byteOffset',0)+a.get('byteOffset',0),strides=(b.get('byteStride',dtype.itemsize*width),dtype.itemsize))
 prim=doc['meshes'][0]['primitives'][0];p=array(prim['attributes']['POSITION']);n=array(prim['attributes']['NORMAL']);f=array(prim['indices']).reshape(-1,3);return raw,doc,p,n,f
ar,ad,ap,an,af=read(sys.argv[1]);tr,td,tp,tn,tf=read(sys.argv[2]);assert len(ad['meshes'])==len(td['meshes'])==1;assert ad['nodes']==td['nodes'];assert ad['scenes']==td['scenes'];assert len(af)==len(tf);ha=hashlib.sha256();ht=hashlib.sha256()
for i in range(0,len(af),100000):
 a=ap[af[i:i+100000]];b=tp[tf[i:i+100000]];assert np.array_equal(a,b),(i,'Spatial triangle mismatch');assert np.array_equal(an[af[i:i+100000]],tn[tf[i:i+100000]]),(i,'Normal mismatch');ha.update(a.tobytes());ht.update(b.tobytes())
assert ha.hexdigest()==ht.hexdigest()
print(json.dumps({'passed':True,'validator':'Independent stdlib/NumPy GLB reader, no transfer code imported','sourceASha256':hashlib.sha256(ar).hexdigest(),'testSha256':hashlib.sha256(tr).hexdigest(),'sourceTriangles':len(af),'testTriangles':len(tf),'allTriangleCoordinatesAndWindingExactlyEqual':True,'allOriginalNormalsExactlyEqual':True,'maxCoordinateDifference':0,'spatialTriangleSha256':ha.hexdigest()},indent=2))
